package com.riddle.camsr2d2;

import android.content.Context;
import java.util.*;

final class CommandCatalog {
    private final List<CommandItem> all = new ArrayList<>();
    CommandCatalog(Context context) {
        add("AppModeSignal","Keep Alive",0,Protocol.KEEP_ALIVE); add("AppModeSignal","Power Down",1,Protocol.POWER_DOWN);
        for(int i=1;i<=8;i++) add("CamPosition",bodyName(i),i,Protocol.cam(i));
        add("HeadPosition","Head Left",0,Protocol.head(0)); add("HeadPosition","Head Center",1,Protocol.head(1)); add("HeadPosition","Head Right",2,Protocol.head(2));
        add("LEDColor","Lights Off",0,Protocol.led(0,0)); add("LEDColor","Full Red",1,Protocol.led(255,0)); add("LEDColor","Full Blue",2,Protocol.led(0,255)); add("LEDColor","Red + Blue",3,Protocol.led(255,255));
        add("Motor2Direction","Motor Stop",0,Protocol.motor(0)); add("Motor2Direction","Motor Forward",1,Protocol.motor(1)); add("Motor2Direction","Motor Backward",2,Protocol.motor(2));
        for(int i=0;i<175;i++) add("PNum",soundName(i),i,Protocol.audio(i));
        for(int i=0;i<478;i++) add("HLSequence",hlName(i),i,Protocol.sequence(Protocol.SEQ_HIGH_LEVEL,i));
        for(int i=0;i<478;i++) add("MotorSequence",motorName(i),i,Protocol.sequence(Protocol.SEQ_MOTOR,i));
        for(int i=0;i<265;i++) add("LEDSequence",ledName(i),i,Protocol.sequence(Protocol.SEQ_LED,i));
        for(int i=0;i<9;i++) add("mMotorSequences","Manual Motor Routine "+String.format(Locale.US,"%02d",i+1),i,Protocol.sequence(Protocol.SEQ_MOTOR,i));
        AppLog.add("Generated "+all.size()+" recovered protocol commands.");
    }
    private void add(String c,String n,int id,byte[] p){all.add(new CommandItem(c,n,id,p));}
    private String bodyName(int i){String[] n={"","Head Position 1","Head Position 2","Pivot Left Upright","Drive Upright","Pivot Right Upright","Pivot Right","Drive","Pivot Left"};return n[i];}
    private static final String[] AUDIO_NAMES = {
            "P001_BabbleBack_009b",
            "P002_BabbleBack_031b",
            "P003_BabbleBack_057",
            "P004_BabbleBack_009a",
            "P005_BabbleBack_023",
            "P006_BabbleBack_024b",
            "P007_BabbleBack_024c",
            "P008_BabbleBack_043",
            "P009_BabbleBack_081",
            "P010_BabbleBack_029b",
            "P011_BabbleBack_029d",
            "P012_BabbleBack_052",
            "P013_BabbleBack_045",
            "P014_BabbleBack_093",
            "P015_BabbleBack_094",
            "P016_BabbleBack_095",
            "P017_BabbleBack_096",
            "P018_BabbleBack_097",
            "P019_BabbleBack_010b",
            "P020_BabbleBack_042",
            "P021_BabbleBack_044",
            "P022_BabbleBack_060",
            "P023_BabbleBack_073",
            "P024_BabbleBack_001",
            "P025_BabbleBack_003",
            "P026_BabbleBack_008b",
            "P027_BabbleBack_012b",
            "P028_BabbleBack_027c",
            "P029_BabbleBack_029c",
            "P030_BabbleBack_030a",
            "P031_BabbleBack_030d",
            "P032_BabbleBack_031a",
            "P033_BabbleBack_037",
            "P034_BabbleBack_038",
            "P035_BabbleBack_046",
            "P036_BabbleBack_047",
            "P037_BabbleBack_063",
            "P038_BabbleBack_071",
            "P039_BabbleBack_086",
            "P040_BabbleBack_007",
            "P041_BabbleBack_014a",
            "P042_BabbleBack_019",
            "P043_BabbleBack_020a",
            "P044_BabbleBack_013a",
            "P045_BabbleBack_028c",
            "P046_BabbleBack_031c",
            "P047_BabbleBack_069",
            "P048_BabbleBack_005a",
            "P049_BabbleBack_022",
            "P050_BabbleBack_022a",
            "P051_BabbleBack_026b",
            "P052_BabbleBack_028b",
            "P053_BabbleBack_030b",
            "P054_BabbleBack_030e",
            "P055_BabbleBack_040",
            "P056_BabbleBack_070",
            "P057_BabbleBack_075",
            "P058_BabbleBack_015b",
            "P059_BabbleBack_015d",
            "P060_BabbleBack_022b",
            "P061_BabbleBack_048",
            "P062_BabbleBack_076",
            "P063_BabbleBack_077",
            "P064_BabbleBack_002",
            "P065_BabbleBack_012a",
            "P066_BabbleBack_015a",
            "P067_BabbleBack_015c",
            "P068_BabbleBack_062",
            "P069_BabbleBack_061",
            "P070_BabbleBack_107",
            "P071_BabbleBack_108",
            "P072_BabbleBack_109",
            "P073_BabbleBack_110",
            "P074_BabbleBack_111",
            "P075_BabbleBack_112",
            "P076_Droid_Relieved02",
            "P077_BabbleBack_013b",
            "P078_BabbleBack_087",
            "P079_BabbleBack_088",
            "P080_BabbleBack_089",
            "P081_BabbleBack_090",
            "P082_BabbleBack_091",
            "P083_BabbleBack_092",
            "P084_BabbleBack_008a",
            "P085_BabbleBack_006",
            "P086_BabbleBack_011a",
            "P087_BabbleBack_049",
            "P088_BabbleBack_051",
            "P089_BabbleBack_058",
            "P090_BabbleBack_064",
            "P091_BabbleBack_034a",
            "P092_BabbleBack_034b",
            "P093_BabbleBack_041",
            "P094_BabbleBack_098",
            "P095_BabbleBack_099",
            "P096_BabbleBack_100",
            "P097_BabbleBack_101",
            "P098_BabbleBack_102",
            "P099_BabbleBack_103",
            "P100_BabbleBack_104",
            "P101_BabbleBack_105",
            "P102_Droid_Startled03",
            "P103_Droid_Startled04",
            "P104_BabbleBack_011b",
            "P105_BabbleBack_014b",
            "P106_BabbleBack_033",
            "P107_BabbleBack_039",
            "P108_BabbleBack_078",
            "P109_BabbleBack_083",
            "P110_BabbleBack_084",
            "P111_BabbleBack_085",
            "P112_BabbleBack_005b",
            "P113_BabbleBack_016a",
            "P114_BabbleBack_016b",
            "P115_BabbleBack_016c",
            "P116_BabbleBack_017",
            "P117_BabbleBack_018",
            "P118_BabbleBack_021a",
            "P119_BabbleBack_021b",
            "P120_BabbleBack_024a",
            "P121_BabbleBack_027a",
            "P122_BabbleBack_027b",
            "P123_BabbleBack_028a",
            "P124_BabbleBack_029a",
            "P125_BabbleBack_030c",
            "P126_BabbleBack_032",
            "P127_BabbleBack_035",
            "P128_BabbleBack_036",
            "P129_BabbleBack_050",
            "P130_BabbleBack_053",
            "P131_BabbleBack_054",
            "P132_BabbleBack_055",
            "P133_BabbleBack_056",
            "P134_BabbleBack_059a",
            "P135_BabbleBack_059b",
            "P136_BabbleBack_068",
            "P137_BabbleBack_080",
            "P138_BabbleBack_082",
            "P139_StationaryMode",
            "P140_MobileMode",
            "P141_GuardMode",
            "P142_SFX_GuardModeCountDown5",
            "P143_IsThatYou1",
            "P144_SFX_IntruderAlarm02_Loop",
            "P145_SFX_IntruderAlarm02_Tail",
            "P147_SFX_AlarmDeactivated03",
            "P149_WakeUp2",
            "P151_Droid_ControlledByForce06",
            "P152_Humming1",
            "P153_Humming2",
            "P154_Humming3",
            "P155_SFX_GoingToSleep07",
            "P156_SFX_Whistle01",
            "P157_SFX_Whistle02",
            "P158_SFX_Whistle03",
            "P159_SFX_Whistle04",
            "P160_SFX_Whistle05",
            "P161_Droid_Achievement03",
            "P162_Droid_V3a",
            "P163_Droid_V3b",
            "P164_Droid_V3c",
            "P165_Droid_V3d",
            "P166_Droid_V3e",
            "P167_Droid_V3f",
            "P168_Droid_V3g",
            "P169_Cantina_Part2",
            "P169_Droid_Cantina_1REV",
            "P170_Droid_ControlledByForce07",
            "P171_Unlock_Alarm",
            "P172_Unlock_Scan",
            "P173__Unlock_Interface",
            "P174_Unlock_Celebrate",
            "P175_Unlock_Overload",
            "P176_Unlock_Runaway",
            "P177_Unlock_Berserk"
    };
    private String soundName(int i){return i>=0&&i<AUDIO_NAMES.length?AUDIO_NAMES[i]:"Audio / Playlist "+String.format(Locale.US,"%03d",i);}
    private String hlName(int i){if(i>=445&&i<=452)return "Relieved "+(i-444);if(i>=453&&i<=460)return "Song "+(i-452);if(i>=461&&i<=473)return "Startled "+(i-460);if(i>=475&&i<=477)return "Wakeup "+(i-474);if(i>=430&&i<=444)return "Obstacle Reaction "+(i-429);return "High-Level Routine "+String.format(Locale.US,"%03d",i);}
    private String motorName(int i){if(i==1)return "Alarm";if(i==2)return "Berserk";if(i==13)return "Celebrate";if(i>=200&&i<=229)return "Turn Left "+(i-199);if(i>=230&&i<=259)return "Turn Right "+(i-229);return "Motor Routine "+String.format(Locale.US,"%03d",i);}
    private String ledName(int i){return "LED Effect "+String.format(Locale.US,"%03d",i);}
    List<CommandItem> all(){return Collections.unmodifiableList(all);}
    List<CommandItem> search(String query,String category,int limit){String q=query==null?"":query.trim().toLowerCase(Locale.US);String c=category==null?"All":category;List<CommandItem> r=new ArrayList<>();for(CommandItem i:all){if(!"All".equals(c)&&!i.category.equals(c))continue;String h=(i.name+" "+i.category+" "+i.id+" "+Protocol.hex(i.packet)).toLowerCase(Locale.US);if(!q.isEmpty()&&!h.contains(q))continue;r.add(i);if(r.size()>=limit)break;}return r;}
    CommandItem findByCategoryAndId(String c,int id){for(CommandItem i:all)if(i.category.equals(c)&&i.id==id)return i;return null;}
    CommandItem randomSound(String mood){
        String q=mood==null?"":mood.trim().toLowerCase(Locale.US);
        int[] ids;
        if(q.contains("music")||q.contains("tune")) ids=new int[]{148,149,150,165,166};
        else if(q.contains("alert")||q.contains("alarm")) ids=new int[]{143,144,168,172,174};
        else if(q.contains("happy")||q.contains("celebrate")) ids=new int[]{152,153,154,155,156,157,171};
        else if(q.contains("surprise")||q.contains("silly")) ids=new int[]{158,159,160,161,162,163,164,167,172,173,174};
        else if(q.contains("talk")||q.contains("chatter")||q.contains("babble")) {
            int id=(int)(Math.random()*138); return findByCategoryAndId("PNum",id);
        } else return randomCategory("PNum");
        return findByCategoryAndId("PNum",ids[(int)(Math.random()*ids.length)]);
    }
    CommandItem randomCategory(String c){List<CommandItem> m=search("",c,5000);return m.isEmpty()?null:m.get((int)(Math.random()*m.size()));}
}
