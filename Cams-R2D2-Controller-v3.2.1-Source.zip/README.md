# Cam's R2-D2 Command Center v3.2

Tablet-first Android controller for the Hasbro Smart R2-D2. v3.2 keeps the v3.1 feature set and adds Nintendo Switch / standard Android game-controller input plus a corrected recovered audio catalog.

## v3.2 additions

- Controller Mode: left stick drives, right stick controls the head, face/shoulder/trigger/D-pad buttons run actions.
- Dedicated Cantina controls using recovered audio IDs 166 (`P169_Droid_Cantina_1REV`) and 165 (`P169_Cantina_Part2`).
- All 175 recovered audio playlist names are now shown in the command library instead of generic `Audio / Playlist ###` labels.
- Random sound categories are curated rather than accidentally falling back to the entire sound table when words such as `happy`, `alert`, or `talk` do not occur in the original asset names.

## Controller pairing

Pair the Nintendo Switch controller in Android Bluetooth settings. Then open **Controller Mode** in the app. Controller input is armed only while that screen is open, and leaving it stops drive motion.

## Upgrade signing note

Android updates require the same package ID and signing certificate. This project keeps `com.riddle.r2d2controller`. Retain the existing v3 release key for every v3+ update.

- Voice Commands: say **“Cantina”** to play audio ID 166 directly.
