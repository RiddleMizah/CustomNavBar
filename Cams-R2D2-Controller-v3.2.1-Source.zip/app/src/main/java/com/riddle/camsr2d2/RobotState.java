package com.riddle.camsr2d2;

import java.util.Locale;

final class RobotState {
    enum Head { LEFT, CENTER, RIGHT, UNKNOWN }
    enum Body {
        HEAD_1, HEAD_2, PIVOT_LEFT_UPRIGHT, DRIVE_UPRIGHT,
        PIVOT_RIGHT_UPRIGHT, PIVOT_RIGHT, DRIVE, PIVOT_LEFT, UNKNOWN
    }

    volatile Head head = Head.UNKNOWN;
    volatile Body body = Body.UNKNOWN;
    volatile int grayCode = -1;
    volatile int micEvent = 0;
    volatile int irAmbient = 0;
    volatile int irLit = 0;
    volatile int rssi = 0;
    volatile long lastPacketAt = 0L;
    volatile String lastPacketHex = "";

    synchronized void apply(byte[] data) {
        if (data == null || data.length == 0) return;
        lastPacketAt = System.currentTimeMillis();
        lastPacketHex = Protocol.hex(data);
        int opcode = data[0] & 0xFF;
        if (opcode == 0x20 && data.length >= 3) {
            int raw = Protocol.u16(data, 1);
            grayCode = (raw >> 3) & 0x0F;
            body = bodyFromGray(grayCode);
            int headRaw = (raw >> 7) & 0x03;
            if (headRaw == 0) head = Head.RIGHT;
            else if (headRaw == 1) head = Head.LEFT;
            else head = Head.CENTER;
        } else if (opcode == 0x1B && data.length >= 2) {
            micEvent = data[1] & 0xFF;
        } else if (opcode == 0x16 && data.length >= 7) {
            irAmbient = Protocol.u16(data, 3);
            irLit = Protocol.u16(data, 5);
        }
    }

    synchronized void predictHead(int target) {
        head = target == Protocol.HEAD_LEFT ? Head.LEFT : target == Protocol.HEAD_RIGHT ? Head.RIGHT : Head.CENTER;
    }

    synchronized void predictBody(int target) {
        switch (target) {
            case 1: body = Body.HEAD_1; break;
            case 2: body = Body.HEAD_2; break;
            case 3: body = Body.PIVOT_LEFT_UPRIGHT; break;
            case 4: body = Body.DRIVE_UPRIGHT; break;
            case 5: body = Body.PIVOT_RIGHT_UPRIGHT; break;
            case 6: body = Body.PIVOT_RIGHT; break;
            case 7: body = Body.DRIVE; break;
            case 8: body = Body.PIVOT_LEFT; break;
            default: body = Body.UNKNOWN;
        }
    }

    boolean obstacleClose() { return irLit >= irAmbient && irLit - irAmbient > 1500; }

    String micLabel() {
        switch (micEvent) {
            case 1: return "Sharp sound / clap";
            case 2: return "Voice";
            case 3: return "Music";
            case 4: return "Sound ongoing";
            case 5: return "Sound finished";
            default: return "Quiet";
        }
    }

    String summary() {
        return String.format(Locale.US, "Body: %s\nHead: %s\nCam Gray: %d\nMic: %s\nIR ambient/lit: %d / %d\nObstacle: %s\nRSSI: %d dBm\nLast RX: %s",
                body, head, grayCode, micLabel(), irAmbient, irLit, obstacleClose(), rssi, lastPacketHex.isEmpty() ? "none" : lastPacketHex);
    }

    static Body bodyFromGray(int gray) {
        switch (gray) {
            case 0: return Body.HEAD_1;
            case 3: return Body.HEAD_2;
            case 6: return Body.PIVOT_LEFT_UPRIGHT;
            case 5: return Body.DRIVE_UPRIGHT;
            case 12: return Body.PIVOT_RIGHT_UPRIGHT;
            case 15: return Body.PIVOT_RIGHT;
            case 10: return Body.DRIVE;
            case 9: return Body.PIVOT_LEFT;
            default: return Body.UNKNOWN;
        }
    }
}
