package com.riddle.camsr2d2;

import org.json.JSONException;
import org.json.JSONObject;

final class RoutineStep {
    enum Kind { ACTION, PACKET, WAIT }
    final Kind kind;
    final ActionType action;
    final byte[] packet;
    final String label;
    final long delayBeforeMs;
    final long durationMs;
    final int repeat;

    RoutineStep(ActionType action, long delayBeforeMs, long durationMs) {
        this(Kind.ACTION, action, null, action.label, delayBeforeMs, durationMs, 1);
    }
    static RoutineStep packet(String label, byte[] packet, long delay, long duration) {
        return new RoutineStep(Kind.PACKET, null, packet, label, delay, duration, 1);
    }
    static RoutineStep waitMs(long ms) { return new RoutineStep(Kind.WAIT, null, null, "Wait " + ms + " ms", 0, ms, 1); }
    RoutineStep withRepeat(int count) { return new RoutineStep(kind, action, packet, label, delayBeforeMs, durationMs, Math.max(1,count)); }
    private RoutineStep(Kind kind, ActionType action, byte[] packet, String label, long delay, long duration, int repeat) {
        this.kind=kind; this.action=action; this.packet=packet==null?null:packet.clone(); this.label=label;
        this.delayBeforeMs=Math.max(0,delay); this.durationMs=Math.max(0,duration); this.repeat=Math.max(1,repeat);
    }
    boolean isMotion() { return kind==Kind.ACTION && action!=null && action.motion; }
    String displayLabel() { return repeat > 1 ? label + " ×" + repeat : label; }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject().put("kind",kind.name()).put("label",label).put("delayBeforeMs",delayBeforeMs)
                .put("durationMs",durationMs).put("repeat",repeat);
        if(action!=null)o.put("action",action.name());
        if(packet!=null)o.put("packet",Protocol.hex(packet));
        return o;
    }
    static RoutineStep fromJson(JSONObject o) throws JSONException {
        if(!o.has("kind")) return new RoutineStep(ActionType.valueOf(o.getString("action")),o.optLong("delayBeforeMs"),o.optLong("durationMs"));
        Kind k=Kind.valueOf(o.getString("kind"));
        ActionType a=o.has("action")?ActionType.valueOf(o.getString("action")):null;
        byte[] p=o.has("packet")?Protocol.parseHex(o.getString("packet")):null;
        return new RoutineStep(k,a,p,o.optString("label",a==null?k.name():a.label),o.optLong("delayBeforeMs"),o.optLong("durationMs"),o.optInt("repeat",1));
    }
}
