package com.riddle.camsr2d2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.*;

final class VoiceController implements RecognitionListener {
    interface Listener { void onVoiceStatus(String status,String heard); }
    private final Context context; private final MotionController motion; private final CommandCatalog catalog; private final AppPreferences prefs; private final Listener listener;
    private SpeechRecognizer recognizer; private boolean listening;
    VoiceController(Context c,MotionController m,CommandCatalog cat,AppPreferences p,Listener l){context=c;motion=m;catalog=cat;prefs=p;listener=l;}
    boolean available(){return SpeechRecognizer.isRecognitionAvailable(context);}
    void start(){if(!available()){listener.onVoiceStatus("Voice recognition unavailable","");return;}stop();recognizer=SpeechRecognizer.createSpeechRecognizer(context);recognizer.setRecognitionListener(this);Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Say an R2-D2 command");listening=true;recognizer.startListening(i);listener.onVoiceStatus("LISTENING…","");}
    void stop(){listening=false;if(recognizer!=null){recognizer.cancel();recognizer.destroy();recognizer=null;}}
    private void handle(String heard){String q=heard.toLowerCase(Locale.US);listener.onVoiceStatus("HEARD",heard);
        if(q.contains("stop")||q.contains("quiet")){motion.emergencyStop();motion.stopAudio();}
        else if(q.contains("forward")||q.contains("come alive")){motion.startManual(ActionType.FORWARD);new android.os.Handler().postDelayed(motion::stopManual,1200);}
        else if(q.contains("back")){motion.startManual(ActionType.REVERSE);new android.os.Handler().postDelayed(motion::stopManual,900);}
        else if(q.contains("left")){motion.performAction(ActionType.HEAD_LEFT,false);}
        else if(q.contains("right")){motion.performAction(ActionType.HEAD_RIGHT,false);}
        else if(q.contains("center")){motion.performAction(ActionType.HEAD_CENTER,false);}
        else if(q.contains("red alert")){motion.performAction(ActionType.LIGHT_RED,false);motion.performAction(ActionType.ACHIEVEMENT,false);}
        else if(q.contains("sleep")){motion.performAction(ActionType.HEAD_CENTER,false);motion.performAction(ActionType.LIGHTS_OFF,false);motion.emergencyStop();}
        else if(q.contains("dance")||q.contains("surprise")){CommandItem item=catalog.randomCategory("HLSequence");if(item!=null)motion.sendPacket(item.name,item.packet,false);}
        else if(q.contains("cantina")){motion.playAudio(Protocol.AUDIO_CANTINA);}
        else if(q.contains("song")||q.contains("music")){int[] ids={453,454,455,456,457,458,459};motion.playSequence(Protocol.SEQ_HIGH_LEVEL,ids[(int)(Math.random()*ids.length)]);}
        else listener.onVoiceStatus("UNKNOWN COMMAND",heard);
    }
    @Override public void onReadyForSpeech(Bundle p){listener.onVoiceStatus("READY","");}@Override public void onBeginningOfSpeech(){listener.onVoiceStatus("HEARING YOU…","");}@Override public void onRmsChanged(float r){}@Override public void onBufferReceived(byte[] b){}@Override public void onEndOfSpeech(){listener.onVoiceStatus("PROCESSING…","");}
    @Override public void onError(int e){listening=false;listener.onVoiceStatus("VOICE ERROR "+e,"");}
    @Override public void onResults(Bundle r){listening=false;ArrayList<String> v=r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(v!=null&&!v.isEmpty())handle(v.get(0));}
    @Override public void onPartialResults(Bundle r){ArrayList<String> v=r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(v!=null&&!v.isEmpty())listener.onVoiceStatus("LISTENING…",v.get(0));}@Override public void onEvent(int e,Bundle b){}
}
