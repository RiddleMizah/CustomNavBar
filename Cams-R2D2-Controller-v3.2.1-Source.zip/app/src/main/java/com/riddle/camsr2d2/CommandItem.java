package com.riddle.camsr2d2;

final class CommandItem {
    final String category;
    final String name;
    final int id;
    final byte[] packet;

    CommandItem(String category, String name, int id, byte[] packet) {
        this.category = category;
        this.name = name;
        this.id = id;
        this.packet = packet;
    }

    String displayName() {
        String cleaned = name.replace("eHL_", "").replace("App_Blk_", "").replace('_', ' ');
        return cleaned + "  •  " + Protocol.hex(packet);
    }
}
