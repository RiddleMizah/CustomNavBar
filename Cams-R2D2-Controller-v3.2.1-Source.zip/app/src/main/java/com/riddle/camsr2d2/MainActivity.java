package com.riddle.camsr2d2;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity implements R2D2Client.Callback, RoutinePlayer.Listener,
        GameEngine.Listener, InteractionEngine.Listener, VoiceController.Listener, TiltController.Listener {

    static final int HOME = 0;
    static final int DRIVE = 1;
    static final int TILT = 2;
    static final int ACTIONS = 3;
    static final int DANCES = 4;
    static final int STUDIO = 5;
    static final int GAMES = 6;
    static final int INTERACTIVE = 7;
    static final int VOICE = 8;
    static final int LIGHTS = 9;
    static final int PARENT = 10;
    static final int LIBRARY = 11;
    static final int REMOTE = 12;

    private static final int PERM_BLE = 1001;
    private static final int PERM_MIC = 1002;

    private final List<Routine> routines = new ArrayList<>();
    private final List<RoutineStep> draft = new ArrayList<>();
    private final RoutineRecorder recorder = new RoutineRecorder();

    private AppPreferences prefs;
    private R2D2Client client;
    private RobotState robot;
    private MotionController motion;
    private CommandCatalog catalog;
    private RoutineStore store;
    private RoutinePlayer player;
    private GameEngine games;
    private InteractionEngine interactions;
    private VoiceController voice;
    private TiltController tilt;
    private GamepadController gamepad;

    private FrameLayout content;
    private TextView statusPill;
    private TextView screenTitle;
    private TextView recordingBanner;
    private TextView playbackBanner;
    private Button connectButton;
    private int currentScreen = HOME;

    String latestStatus = "Not connected";
    String latestDevice = "";
    String gameTitle = "Games";
    String gameDetail = "Pick a game to begin";
    String interactiveStatus = "All interactive modes start OFF";
    String voiceStatus = "Ready to listen";
    String voiceHeard = "";
    String tiltStatus = "SAFE / STOPPED";
    float tiltX;
    float tiltY;
    String gamepadStatus = "No game controller detected";
    String gamepadInput = "Open Controller Mode to arm the gamepad";

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = new AppPreferences(this);
        robot = new RobotState();
        store = new RoutineStore(this);
        routines.addAll(store.load());
        catalog = new CommandCatalog(this);
        client = new R2D2Client(this, this);
        motion = new MotionController(this, client, recorder, robot, prefs);
        player = new RoutinePlayer(motion, this);
        games = new GameEngine(motion, catalog, prefs, this);
        interactions = new InteractionEngine(motion, catalog, prefs, this);
        voice = new VoiceController(this, motion, catalog, prefs, this);
        tilt = new TiltController(this, motion, prefs, this);
        gamepad = new GamepadController(this, motion);
        setContentView(buildShell());
        showScreen(HOME);
        AppLog.add("R2-D2 Controller 3.2 opened.");
    }

    private View buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.color(Ui.PALE));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 8));
        top.setBackgroundColor(Ui.color(Ui.WHITE));
        top.setElevation(Ui.dp(this, 5));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_cams_droid);
        icon.setOnLongClickListener(v -> {
            showScreen(PARENT);
            return true;
        });
        top.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 54), Ui.dp(this, 54)));

        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.setPadding(Ui.dp(this, 10), 0, 0, 0);
        names.addView(Ui.text(this, prefs.possessiveName() + " R2-D2", 22, true, Ui.NAVY));
        screenTitle = Ui.text(this, "Home", 13, false, Ui.MUTED);
        names.addView(screenTitle);
        top.addView(names, new LinearLayout.LayoutParams(0, -2, 1));

        Button home = Ui.button(this, "⌂ HOME", "#D8EFFC", Ui.NAVY, 13);
        home.setOnClickListener(v -> showScreen(HOME));
        top.addView(home, buttonParams(92));

        statusPill = Ui.chip(this, latestStatus, "#8199AA");
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-2, Ui.dp(this, 40));
        statusParams.setMargins(Ui.dp(this, 8), 0, 0, 0);
        top.addView(statusPill, statusParams);

        connectButton = Ui.button(this, "CONNECT", Ui.BLUE, Ui.WHITE, 14);
        connectButton.setOnClickListener(v -> {
            if (client.isReady()) disconnectR2D2();
            else requestConnection();
        });
        top.addView(connectButton, buttonParams(112));

        Button stop = Ui.button(this, "■ STOP", Ui.RED, Ui.WHITE, 14);
        stop.setOnClickListener(v -> emergencyStop());
        top.addView(stop, buttonParams(100));
        root.addView(top, new LinearLayout.LayoutParams(-1, Ui.dp(this, 72)));

        recordingBanner = Ui.banner(this, "● RECORDING — TAP TO FINISH", Ui.RED);
        recordingBanner.setVisibility(View.GONE);
        recordingBanner.setOnClickListener(v -> finishRecording());
        LinearLayout.LayoutParams bannerParams = new LinearLayout.LayoutParams(-1, Ui.dp(this, 42));
        bannerParams.setMargins(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), 0);
        root.addView(recordingBanner, bannerParams);

        playbackBanner = Ui.banner(this, "Playing routine", Ui.NAVY);
        playbackBanner.setVisibility(View.GONE);
        playbackBanner.setOnClickListener(v -> player.stop());
        LinearLayout.LayoutParams playParams = new LinearLayout.LayoutParams(-1, Ui.dp(this, 42));
        playParams.setMargins(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), 0);
        root.addView(playbackBanner, playParams);

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        return root;
    }

    private LinearLayout.LayoutParams buttonParams(int widthDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(Ui.dp(this, widthDp), Ui.dp(this, 44));
        params.setMargins(Ui.dp(this, 8), 0, 0, 0);
        return params;
    }

    void showScreen(int screen) {
        if (gamepad != null) gamepad.setActive(screen == REMOTE && prefs.enabled("controller", true));
        currentScreen = screen;
        if (content == null) return;
        content.removeAllViews();
        View view;
        String title;
        switch (screen) {
            case DRIVE: title = "Drive R2-D2"; view = V3Screens.drive(this); break;
            case TILT: title = "Tilt Drive"; view = V3Screens.tilt(this); break;
            case ACTIONS: title = "R2-D2 Sounds"; view = V3Screens.actions(this); break;
            case DANCES: title = "Dances"; view = V3Screens.dances(this); break;
            case STUDIO: title = "Build a Routine"; view = V3Screens.studio(this); break;
            case GAMES: title = "Games"; view = V3Screens.games(this); break;
            case INTERACTIVE: title = "Interactive Modes"; view = V3Screens.interactive(this); break;
            case VOICE: title = "Voice Commands"; view = V3Screens.voice(this); break;
            case LIGHTS: title = "Lights"; view = V3Screens.lights(this); break;
            case PARENT: title = "Parent Mode"; view = V3Screens.parent(this); break;
            case LIBRARY: title = "Full Command Library"; view = V3Screens.library(this); break;
            case REMOTE: title = "Controller Mode"; view = V3Screens.remote(this); break;
            default: title = "Home"; view = V3Screens.home(this); break;
        }
        screenTitle.setText(title);
        content.addView(view, new FrameLayout.LayoutParams(-1, -1));
    }

    AppPreferences prefs() { return prefs; }
    MotionController motion() { return motion; }
    CommandCatalog catalog() { return catalog; }
    RobotState robot() { return robot; }
    GameEngine games() { return games; }
    VoiceController voice() { return voice; }
    TiltController tilt() { return tilt; }
    GamepadController gamepad() { return gamepad; }
    List<Routine> routines() { return routines; }
    List<RoutineStep> draft() { return draft; }
    boolean isR2Ready() { return client.isReady(); }
    boolean isRecording() { return recorder.isRecording(); }
    String controllerName() { return prefs.controllerName(); }

    void requestConnection() {
        if (client.isReady()) return;
        BluetoothAdapter adapter = client.adapter();
        if (adapter == null) { toastMessage("Bluetooth is not available"); return; }
        if (!adapter.isEnabled()) { startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return; }
        String[] permissions = Build.VERSION.SDK_INT >= 31
                ? new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}
                : new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
        for (String permission : permissions) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(permissions, PERM_BLE);
                return;
            }
        }
        client.startScan();
    }

    void requestVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PERM_MIC);
            return;
        }
        voice.start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        for (int grant : grants) {
            if (grant != PackageManager.PERMISSION_GRANTED) {
                toastMessage("Permission denied");
                return;
            }
        }
        if (requestCode == PERM_BLE) client.startScan();
        else if (requestCode == PERM_MIC) voice.start();
    }

    void disconnectR2D2() {
        if (player.isPlaying()) player.stop();
        games.stop();
        tilt.stop();
        motion.emergencyStop();
        client.disconnect();
    }

    void reconnect() { client.disconnect(); requestConnection(); }

    void emergencyStop() {
        games.stop();
        tilt.stop();
        if (player.isPlaying()) player.stop();
        motion.emergencyStop();
    }

    void startManualMotion(ActionType action) {
        if (player.isPlaying()) player.stop();
        motion.startManual(action);
    }

    void stopManualMotion() { motion.stopManual(); }
    void performAction(ActionType action, boolean record) { motion.performAction(action, record); }

    void startRecording() {
        if (player.isPlaying()) player.stop();
        recorder.start();
        recordingBanner.setVisibility(View.VISIBLE);
        showScreen(DRIVE);
        toastMessage("Recording started");
    }

    void finishRecording() {
        List<RoutineStep> steps = recorder.finish();
        recordingBanner.setVisibility(View.GONE);
        if (steps.isEmpty()) { toastMessage("Nothing was recorded"); return; }
        askRoutineName("My R2-D2 Routine", name -> {
            routines.add(Routine.custom(name, steps));
            store.save(routines);
            showScreen(STUDIO);
        });
    }

    void addDraft(RoutineStep step) {
        draft.add(step);
        toastMessage("Added: " + step.displayLabel());
        if (currentScreen == STUDIO) showScreen(STUDIO);
    }

    void clearDraft() {
        draft.clear();
        showScreen(STUDIO);
    }

    void saveDraft() {
        if (draft.isEmpty()) { toastMessage("Add some blocks first"); return; }
        askRoutineName("My New Routine", name -> {
            routines.add(Routine.custom(name, new ArrayList<>(draft)));
            store.save(routines);
            draft.clear();
            showScreen(STUDIO);
        });
    }

    private void askRoutineName(String title, java.util.function.Consumer<String> done) {
        EditText edit = new EditText(this);
        edit.setText(title);
        new AlertDialog.Builder(this)
                .setTitle("Name this routine")
                .setView(edit)
                .setPositiveButton("Save", (dialog, which) -> {
                    String value = edit.getText().toString().trim();
                    done.accept(value.isEmpty() ? title : value);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    void playRoutine(Routine routine) {
        if (!client.isReady()) { toastMessage("Connect R2-D2 first"); return; }
        player.play(routine);
    }

    void deleteRoutine(Routine routine) {
        routines.remove(routine);
        store.save(routines);
        showScreen(STUDIO);
    }

    void randomExpression(String mood) {
        String query = mood.toLowerCase(Locale.US);
        List<CommandItem> hits = catalog.search(query, "HLSequence", 200);
        CommandItem item = hits.isEmpty() ? catalog.randomCategory("HLSequence")
                : hits.get((int) (Math.random() * hits.size()));
        if (item != null) motion.sendPacket(item.name, item.packet, false);
    }

    void playRandomSound(String query) {
        CommandItem item = catalog.randomSound(query);
        if (item != null) motion.sendPacket(item.name, item.packet, false);
    }

    void playCantina() {
        motion.playAudio(Protocol.AUDIO_CANTINA);
        AppLog.add("Cantina song requested directly (audio 166).");
    }

    void playCantinaPart2() {
        motion.playAudio(Protocol.AUDIO_CANTINA_PART2);
        AppLog.add("Cantina Part 2 requested directly (audio 165).");
    }

    void playRandomDance() {
        CommandItem item = catalog.randomCategory("HLSequence");
        if (item != null) motion.sendPacket(item.name, item.packet, false);
    }

    void exportRoutines() {
        JSONArray array = new JSONArray();
        try {
            for (Routine routine : routines) array.put(routine.toJson());
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("R2-D2 routines", array.toString(2)));
            toastMessage("Routines copied");
        } catch (Exception e) { toastMessage(e.getMessage()); }
    }

    void importRoutines() {
        EditText edit = new EditText(this);
        edit.setMinLines(5);
        new AlertDialog.Builder(this)
                .setTitle("Paste exported routine JSON")
                .setView(edit)
                .setPositiveButton("Import", (dialog, which) -> {
                    try {
                        JSONArray array = new JSONArray(edit.getText().toString());
                        for (int i = 0; i < array.length(); i++) routines.add(Routine.fromJson(array.getJSONObject(i)));
                        store.save(routines);
                        toastMessage("Imported " + array.length() + " routines");
                    } catch (Exception e) { toastMessage("Import failed: " + e.getMessage()); }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    void editControllerName() {
        EditText edit = new EditText(this);
        edit.setText(prefs.controllerName());
        new AlertDialog.Builder(this)
                .setTitle("Controller name")
                .setView(edit)
                .setPositiveButton("Save", (dialog, which) -> {
                    prefs.setControllerName(edit.getText().toString());
                    recreate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    void rawPacketDialog() {
        EditText edit = new EditText(this);
        edit.setHint("Example: 17 02 CD 01");
        new AlertDialog.Builder(this)
                .setTitle("Send raw hex packet")
                .setView(edit)
                .setPositiveButton("Send", (dialog, which) -> {
                    try { motion.sendPacket("Raw packet", Protocol.parseHex(edit.getText().toString()), false); }
                    catch (Exception e) { toastMessage(e.getMessage()); }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    void experimentalVolumeDialog() {
        SeekBar slider = new SeekBar(this);
        slider.setMax(255);
        slider.setProgress(128);
        new AlertDialog.Builder(this)
                .setTitle("Experimental volume")
                .setMessage("The original app declared this command but did not prove its payload. Use carefully.")
                .setView(slider)
                .setPositiveButton("Send", (dialog, which) -> motion.sendPacket(
                        "Experimental volume", Protocol.setVolumeExperimental(slider.getProgress()), false))
                .setNeutralButton("Query", (dialog, which) -> motion.sendPacket(
                        "Volume query", Protocol.requestVolume(), false))
                .setNegativeButton("Cancel", null)
                .show();
    }

    String technicalSummary() {
        String version = "?";
        try { version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception ignored) {}
        return "Version: " + version + "\nPackage: " + getPackageName() + "\nDevice: "
                + Build.MANUFACTURER + " " + Build.MODEL + " API " + Build.VERSION.SDK_INT
                + "\nConnection: " + latestStatus + "\n" + client.diagnostics() + "\n\n" + robot.summary();
    }

    void copyDiagnostics() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("R2-D2 diagnostics", technicalSummary() + "\n\n" + AppLog.text()));
        toastMessage("Diagnostics copied");
    }

    void toastMessage(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }

    @Override
    public void onStatus(String status) {
        runOnUiThread(() -> {
            latestStatus = status;
            if (statusPill != null) {
                statusPill.setText(status);
                statusPill.setBackground(Ui.round(this, client.isReady() ? Ui.GREEN : "#8199AA", 22));
            }
        });
    }

    @Override public void onDevice(String name, String address) { latestDevice = name + "  " + address; }
    @Override public void onLog(String message) {}

    @Override
    public void onConnected(boolean connected) {
        runOnUiThread(() -> {
            connectButton.setText(connected ? "DISCONNECT" : "CONNECT");
            connectButton.setBackground(Ui.round(this, connected ? Ui.GREEN : Ui.BLUE, 18));
            if (!connected) latestDevice = "";
            else client.send(Protocol.requestInput());
            if (currentScreen == HOME) showScreen(HOME);
        });
    }

    @Override public void onPacket(byte[] data) { robot.apply(data); interactions.onPacket(data, robot); }
    @Override public void onRssi(int rssi) { robot.rssi = rssi; }

    @Override
    public void onRoutineStarted(Routine routine) {
        playbackBanner.setVisibility(View.VISIBLE);
        playbackBanner.setText("▶ " + routine.name + " — tap to stop");
    }

    @Override
    public void onRoutineStep(Routine routine, int index, RoutineStep step) {
        playbackBanner.setText("▶ " + routine.name + "  " + (index + 1) + "/" + routine.steps.size()
                + "  " + step.displayLabel());
    }

    @Override
    public void onRoutineFinished(Routine routine, boolean cancelled) {
        playbackBanner.setVisibility(View.GONE);
        if (!cancelled) toastMessage(routine.name + " finished");
    }

    @Override
    public void onGameStatus(String title, String detail, boolean running) {
        gameTitle = title;
        gameDetail = detail;
        runOnUiThread(() -> { if (currentScreen == GAMES) showScreen(GAMES); });
    }

    @Override
    public void onInteractiveStatus(String message) {
        interactiveStatus = message;
        runOnUiThread(() -> { if (currentScreen == INTERACTIVE) showScreen(INTERACTIVE); });
    }

    @Override
    public void onVoiceStatus(String status, String heard) {
        voiceStatus = status;
        voiceHeard = heard;
        runOnUiThread(() -> { if (currentScreen == VOICE) showScreen(VOICE); });
    }

    @Override
    public void onTilt(float x, float y, String action) {
        tiltX = x;
        tiltY = y;
        tiltStatus = action;
        runOnUiThread(() -> { if (currentScreen == TILT) V3Screens.updateTilt(this); });
    }

    @Override
    protected void onPause() {
        super.onPause();
        tilt.stop();
        voice.stop();
        motion.emergencyStop();
    }


    void onGamepadStatus(String value) {
        gamepadStatus = value;
        runOnUiThread(() -> V3Screens.updateGamepad(this));
    }

    void onGamepadInput(String value) {
        gamepadInput = value;
        runOnUiThread(() -> V3Screens.updateGamepad(this));
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if (gamepad != null && gamepad.handleMotionEvent(event)) return true;
        return super.dispatchGenericMotionEvent(event);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (gamepad != null && gamepad.handleKeyEvent(event)) return true;
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onDestroy() {
        games.stop();
        voice.stop();
        tilt.stop();
        if (gamepad != null) gamepad.close();
        client.disconnect();
        super.onDestroy();
    }
}
