package com.riddle.camsr2d2;

import android.hardware.input.InputManager;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;

final class GamepadController implements InputManager.InputDeviceListener {
    private static final float STICK_DEADZONE = 0.28f;
    private static final float HEAD_DEADZONE = 0.42f;
    private static final float TRIGGER_THRESHOLD = 0.60f;

    private final MainActivity activity;
    private final MotionController motion;
    private final InputManager inputManager;
    private boolean active;
    private int headZone;
    private boolean leftTriggerDown;
    private boolean rightTriggerDown;
    private long lastLeftTriggerAction;
    private long lastRightTriggerAction;
    private String deviceName = "No game controller detected";

    GamepadController(MainActivity activity, MotionController motion) {
        this.activity = activity;
        this.motion = motion;
        this.inputManager = (InputManager) activity.getSystemService(android.content.Context.INPUT_SERVICE);
        if (inputManager != null) inputManager.registerInputDeviceListener(this, null);
        refreshDevice();
    }

    void setActive(boolean value) {
        if (active == value) {
            if (active) refreshDevice();
            return;
        }
        active = value;
        if (!active) {
            motion.updateManual(ActionType.STOP);
            headZone = 0;
            leftTriggerDown = rightTriggerDown = false;
            activity.onGamepadInput("Controller mode is off");
        } else {
            refreshDevice();
            activity.onGamepadInput(hasController() ? "Controller armed — move the left stick to drive" :
                    "Pair a controller in Android Bluetooth settings, then return here");
        }
    }

    boolean isActive() { return active; }
    String deviceName() { return deviceName; }

    boolean handleMotionEvent(MotionEvent event) {
        if (!active || event == null || !isJoystickEvent(event)) return false;
        InputDevice device = event.getDevice();
        if (device != null) setDeviceName(device.getName());

        float lx = centeredAxis(event, MotionEvent.AXIS_X);
        float ly = centeredAxis(event, MotionEvent.AXIS_Y);
        float rx = centeredAxis(event, MotionEvent.AXIS_Z);
        if (Math.abs(rx) < 0.01f) rx = centeredAxis(event, MotionEvent.AXIS_RX);

        ActionType drive = ActionType.STOP;
        float ax = Math.abs(lx), ay = Math.abs(ly);
        if (Math.max(ax, ay) >= STICK_DEADZONE) {
            if (ay >= ax) drive = ly < 0 ? ActionType.FORWARD : ActionType.REVERSE;
            else drive = lx < 0 ? ActionType.TURN_LEFT : ActionType.TURN_RIGHT;
        }
        motion.updateManual(drive);

        int nextHead = rx <= -HEAD_DEADZONE ? -1 : rx >= HEAD_DEADZONE ? 1 : 0;
        if (nextHead != headZone) {
            headZone = nextHead;
            if (nextHead < 0) motion.performAction(ActionType.HEAD_LEFT, false);
            else if (nextHead > 0) motion.performAction(ActionType.HEAD_RIGHT, false);
            else motion.performAction(ActionType.HEAD_CENTER, false);
        }

        boolean lt = Math.max(axis(event, MotionEvent.AXIS_LTRIGGER), axis(event, MotionEvent.AXIS_BRAKE)) >= TRIGGER_THRESHOLD;
        boolean rt = Math.max(axis(event, MotionEvent.AXIS_RTRIGGER), axis(event, MotionEvent.AXIS_GAS)) >= TRIGGER_THRESHOLD;
        if (lt && !leftTriggerDown) leftTriggerAction();
        if (rt && !rightTriggerDown) rightTriggerAction();
        leftTriggerDown = lt;
        rightTriggerDown = rt;

        activity.onGamepadInput(String.format(java.util.Locale.US,
                "Left %.2f / %.2f   •   Right %.2f", lx, ly, rx));
        return true;
    }

    boolean handleKeyEvent(KeyEvent event) {
        if (!active || event == null || !isGamepadKey(event)) return false;
        if (event.getAction() != KeyEvent.ACTION_DOWN || event.getRepeatCount() != 0) return recognized(event.getKeyCode());
        InputDevice device = event.getDevice();
        if (device != null) setDeviceName(device.getName());
        int key = event.getKeyCode();
        switch (key) {
            // Android reports physical positions consistently. On a Nintendo layout:
            // south= B, east= A, west= Y, north= X.
            case KeyEvent.KEYCODE_BUTTON_A: motion.performAction(ActionType.WHISTLE, false); note("B: Whistle"); return true;
            case KeyEvent.KEYCODE_BUTTON_B: motion.performAction(ActionType.ACHIEVEMENT, false); note("A: Celebrate"); return true;
            case KeyEvent.KEYCODE_BUTTON_X: motion.performAction(ActionType.WAKE, false); note("Y: Wake up"); return true;
            case KeyEvent.KEYCODE_BUTTON_Y: activity.playCantina(); note("X: Cantina"); return true;
            case KeyEvent.KEYCODE_BUTTON_L1: motion.performAction(ActionType.LIGHT_BLUE, false); note("L: Blue light"); return true;
            case KeyEvent.KEYCODE_BUTTON_R1: motion.performAction(ActionType.LIGHT_RED, false); note("R: Red light"); return true;
            case KeyEvent.KEYCODE_BUTTON_L2: leftTriggerAction(); return true;
            case KeyEvent.KEYCODE_BUTTON_R2: rightTriggerAction(); return true;
            case KeyEvent.KEYCODE_BUTTON_START: activity.emergencyStop(); note("+: EMERGENCY STOP"); return true;
            case KeyEvent.KEYCODE_BUTTON_SELECT: motion.stopAudio(); note("-: Stop sounds"); return true;
            case KeyEvent.KEYCODE_BUTTON_THUMBR: motion.performAction(ActionType.HEAD_CENTER, false); note("Right stick click: Head center"); return true;
            case KeyEvent.KEYCODE_DPAD_UP: activity.playRandomDance(); note("D-pad Up: Random dance"); return true;
            case KeyEvent.KEYCODE_DPAD_DOWN: motion.stopAudio(); note("D-pad Down: Stop sounds"); return true;
            case KeyEvent.KEYCODE_DPAD_LEFT: activity.playCantinaPart2(); note("D-pad Left: Cantina Part 2"); return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT: activity.playRandomSound("talk"); note("D-pad Right: R2 chatter"); return true;
            default: return false;
        }
    }

    private void leftTriggerAction() {
        long now = SystemClock.uptimeMillis();
        if (now - lastLeftTriggerAction < 150) return;
        lastLeftTriggerAction = now;
        motion.performAction(ActionType.LIGHTS_OFF, false);
        note("ZL: Lights off");
    }

    private void rightTriggerAction() {
        long now = SystemClock.uptimeMillis();
        if (now - lastRightTriggerAction < 150) return;
        lastRightTriggerAction = now;
        activity.playRandomSound("");
        note("ZR: Random R2 sound");
    }

    private boolean recognized(int key) {
        switch (key) {
            case KeyEvent.KEYCODE_BUTTON_A: case KeyEvent.KEYCODE_BUTTON_B:
            case KeyEvent.KEYCODE_BUTTON_X: case KeyEvent.KEYCODE_BUTTON_Y:
            case KeyEvent.KEYCODE_BUTTON_L1: case KeyEvent.KEYCODE_BUTTON_R1:
            case KeyEvent.KEYCODE_BUTTON_L2: case KeyEvent.KEYCODE_BUTTON_R2:
            case KeyEvent.KEYCODE_BUTTON_START: case KeyEvent.KEYCODE_BUTTON_SELECT:
            case KeyEvent.KEYCODE_BUTTON_THUMBR:
            case KeyEvent.KEYCODE_DPAD_UP: case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT: case KeyEvent.KEYCODE_DPAD_RIGHT: return true;
            default: return false;
        }
    }

    private float centeredAxis(MotionEvent event, int axis) {
        InputDevice device = event.getDevice();
        if (device == null) return 0f;
        InputDevice.MotionRange range = device.getMotionRange(axis, event.getSource());
        if (range == null) return 0f;
        float value = event.getAxisValue(axis);
        float flat = Math.max(range.getFlat(), 0.08f);
        return Math.abs(value) > flat ? value : 0f;
    }

    private float axis(MotionEvent event, int axis) {
        InputDevice device = event.getDevice();
        if (device == null || device.getMotionRange(axis, event.getSource()) == null) return 0f;
        return event.getAxisValue(axis);
    }

    private boolean isJoystickEvent(MotionEvent event) {
        return (event.getSource() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK;
    }

    private boolean isGamepadKey(KeyEvent event) {
        int source = event.getSource();
        return (source & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                || (source & InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD
                || (source & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK;
    }

    private boolean hasController() {
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice d = InputDevice.getDevice(id);
            if (isController(d)) return true;
        }
        return false;
    }

    private void refreshDevice() {
        String found = null;
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice d = InputDevice.getDevice(id);
            if (isController(d)) { found = d.getName(); break; }
        }
        setDeviceName(found == null ? "No game controller detected" : found);
    }

    private boolean isController(InputDevice d) {
        if (d == null) return false;
        int source = d.getSources();
        return (source & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                || (source & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK;
    }

    private void setDeviceName(String value) {
        if (value == null || value.trim().isEmpty()) value = "Game controller";
        if (!value.equals(deviceName)) {
            deviceName = value;
            activity.onGamepadStatus(deviceName);
        } else activity.onGamepadStatus(deviceName);
    }

    private void note(String value) { activity.onGamepadInput(value); }

    void close() {
        setActive(false);
        if (inputManager != null) inputManager.unregisterInputDeviceListener(this);
    }

    @Override public void onInputDeviceAdded(int deviceId) { refreshDevice(); }
    @Override public void onInputDeviceRemoved(int deviceId) { refreshDevice(); if (!hasController()) motion.updateManual(ActionType.STOP); }
    @Override public void onInputDeviceChanged(int deviceId) { refreshDevice(); }
}
