package com.riddle.camsr2d2;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final class Ui {
    static final String INK = "#12324A";
    static final String MUTED = "#55738B";
    static final String BLUE = "#168BD2";
    static final String NAVY = "#0B5794";
    static final String PALE = "#EAF7FF";
    static final String WHITE = "#FFFFFF";
    static final String RED = "#E54455";
    static final String GREEN = "#32A86B";
    static final String ORANGE = "#F28C28";
    static final String PURPLE = "#8458C8";
    static final String YELLOW = "#F4C542";
    static final String TEAL = "#21A6A1";

    private Ui() {}

    static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    static int color(String hex) {
        return Color.parseColor(hex);
    }

    static GradientDrawable round(Context c, String fill, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color(fill));
        drawable.setCornerRadius(dp(c, radius));
        return drawable;
    }

    static GradientDrawable bordered(Context c, String fill, String stroke, int radius) {
        GradientDrawable drawable = round(c, fill, radius);
        drawable.setStroke(dp(c, 2), color(stroke));
        return drawable;
    }

    static TextView text(Context c, String value, float size, boolean bold, String textColor) {
        TextView view = new TextView(c);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color(textColor));
        if (bold) view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setLineSpacing(0, 1.08f);
        return view;
    }

    static Button button(Context c, String value, String background, String foreground, float size) {
        Button button = new Button(c);
        button.setText(value);
        button.setAllCaps(false);
        button.setTextSize(size);
        button.setTextColor(color(foreground));
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(c, 10), 0, dp(c, 10), 0);
        button.setBackground(round(c, background, 18));
        button.setElevation(dp(c, 3));
        button.setStateListAnimator(null);
        return button;
    }

    static Button bigButton(Context c, String value, String background) {
        Button button = button(c, value, background, WHITE, 19);
        button.setMinHeight(dp(c, 82));
        return button;
    }

    static TextView banner(Context c, String value, String background) {
        TextView view = text(c, value, 15, true, WHITE);
        view.setGravity(Gravity.CENTER);
        view.setBackground(round(c, background, 14));
        return view;
    }

    static LinearLayout card(Context c, String background) {
        LinearLayout layout = new LinearLayout(c);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackground(bordered(c, background, "#CDE5F4", 20));
        layout.setElevation(dp(c, 3));
        return layout;
    }

    static LinearLayout page(Context c) {
        LinearLayout page = new LinearLayout(c);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 28));
        page.setBackgroundColor(color(PALE));
        return page;
    }

    static LinearLayout.LayoutParams matchWrap(Context c, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(dp(c, left), dp(c, top), dp(c, right), dp(c, bottom));
        return params;
    }

    static LinearLayout.LayoutParams weightedButton(Context c) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(c, 52), 1);
        params.setMargins(dp(c, 5), 0, dp(c, 5), 0);
        return params;
    }

    static GridLayout.LayoutParams gridCell(Context c) {
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = GridLayout.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.setMargins(dp(c, 7), dp(c, 7), dp(c, 7), dp(c, 7));
        return params;
    }

    static GridLayout.LayoutParams fixedGridCell(Context c, int heightDp) {
        GridLayout.LayoutParams params = gridCell(c);
        params.height = dp(c, heightDp);
        return params;
    }

    static void addGridSpacer(Context c, GridLayout grid) {
        View spacer = new View(c);
        grid.addView(spacer, fixedGridCell(c, 92));
    }

    static TextView chip(Context c, String value, String background) {
        TextView view = text(c, value, 12, true, WHITE);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(c, 12), dp(c, 7), dp(c, 12), dp(c, 7));
        view.setBackground(round(c, background, 22));
        return view;
    }

    static LinearLayout section(Context c, String title, String subtitle) {
        LinearLayout box = card(c, WHITE);
        box.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 16));
        box.addView(text(c, title, 21, true, INK));
        if (subtitle != null && !subtitle.isEmpty()) {
            box.addView(text(c, subtitle, 13, false, MUTED), matchWrap(c, 0, 4, 0, 12));
        }
        return box;
    }

    static ScrollView scrollPage(Context c, LinearLayout page) {
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(color(PALE));
        scroll.addView(page);
        return scroll;
    }
}
