package com.riddle.camsr2d2;

import java.util.Locale;
import java.util.UUID;

final class Protocol {
    static final String[] DEVICE_PREFIXES = {"Kipps", "2ndHeroD"};
    static final UUID SERVICE_UUID = UUID.fromString("DAB91435-B5A1-E29C-B041-BCD562613BE4");
    static final UUID NOTIFY_UUID = UUID.fromString("DAB91382-B5A1-E29C-B041-BCD562613BE4");
    static final UUID WRITE_UUID = UUID.fromString("DAB91383-B5A1-E29C-B041-BCD562613BE4");
    static final UUID CCCD_UUID = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB");

    static final byte CAM_HEAD_1 = 1, CAM_HEAD_2 = 2, CAM_PIVOT_LEFT_UPRIGHT = 3,
            CAM_DRIVE_UPRIGHT = 4, CAM_PIVOT_RIGHT_UPRIGHT = 5,
            CAM_PIVOT_RIGHT = 6, CAM_DRIVE = 7, CAM_PIVOT_LEFT = 8;
    static final byte MOTOR_STOP = 0, MOTOR_FORWARD = 1, MOTOR_BACKWARD = 2;
    static final int HEAD_LEFT = 0, HEAD_CENTER = 1, HEAD_RIGHT = 2;
    static final int SEQ_LED = 0, SEQ_MOTOR = 1, SEQ_HIGH_LEVEL = 2;
    static final int AUDIO_WAKE = 146, AUDIO_WHISTLE = 152, AUDIO_ACHIEVEMENT = 157,
            AUDIO_CANTINA_PART2 = 165, AUDIO_CANTINA = 166;
    static final byte[] KEEP_ALIVE = {(byte)0x50, (byte)0x8D};
    static final byte[] POWER_DOWN = {(byte)0x50, (byte)0x91};

    private Protocol() {}

    static byte[] head(int position) { return new byte[]{0x13, (byte)position}; }
    static byte[] cam(int position) { return new byte[]{0x12, 0x02, (byte)position}; }
    static byte[] motor(int direction) { return new byte[]{0x14, (byte)direction}; }
    static byte[] led(int red, int blue) { return new byte[]{0x15, (byte)red, (byte)blue}; }
    static byte[] audio(int id) { return new byte[]{0x10, (byte)(id & 0xFF), (byte)((id >> 8) & 0xFF)}; }
    static byte[] sequence(int type, int id) { return new byte[]{0x17, (byte)type, (byte)(id & 0xFF), (byte)((id >> 8) & 0xFF)}; }
    static byte[] stop(int flags) { return new byte[]{0x18, (byte)(flags & 0x3F)}; }
    static byte[] stopAll() { return stop(0x3F); }
    static byte[] stopAudio() { return stop(0x20); }
    static byte[] requestInput() { return new byte[]{0x20}; }
    static byte[] requestLvd() { return new byte[]{0x21}; }
    static byte[] requestVolume() { return new byte[]{0x22}; }
    static byte[] setVolumeExperimental(int value) { return new byte[]{0x23, (byte)Math.max(0, Math.min(255, value))}; }

    static int u16(byte[] data, int offset) {
        return (data[offset] & 0xFF) | ((data[offset + 1] & 0xFF) << 8);
    }

    static byte[] parseHex(String raw) {
        String clean = raw == null ? "" : raw.replaceAll("[^0-9A-Fa-f]", "");
        if (clean.length() == 0 || (clean.length() & 1) != 0) throw new IllegalArgumentException("Enter complete hex bytes");
        byte[] result = new byte[clean.length() / 2];
        for (int i = 0; i < result.length; i++) result[i] = (byte)Integer.parseInt(clean.substring(i * 2, i * 2 + 2), 16);
        return result;
    }

    static String hex(byte[] data) {
        StringBuilder out = new StringBuilder();
        for (byte b : data) {
            if (out.length() > 0) out.append(' ');
            out.append(String.format(Locale.US, "%02X", b & 0xFF));
        }
        return out.toString();
    }
}
