package com.riddle.camsr2d2;

import android.annotation.SuppressLint;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.os.*;
import java.util.*;

final class R2D2Client {
    interface Callback {
        void onStatus(String status); void onDevice(String name,String address); void onLog(String message);
        void onConnected(boolean connected); void onPacket(byte[] data); void onRssi(int rssi);
    }
    private static final long SCAN_TIMEOUT=15000, KEEPALIVE=2000, RSSI=5000;
    private final Context context; private final Callback callback; private final Handler h=new Handler(Looper.getMainLooper());
    private final Queue<byte[]> pending=new ArrayDeque<>(); private final BluetoothAdapter adapter;
    private BluetoothLeScanner scanner; private BluetoothGatt gatt; private BluetoothGattCharacteristic write; private boolean scanning,ready;
    private String name="",address=""; private Runnable keepAlive,rssiPoll; private final Runnable scanTimeout=this::scanTimedOut;

    R2D2Client(Context c,Callback cb){context=c.getApplicationContext();callback=cb;BluetoothManager m=(BluetoothManager)c.getSystemService(Context.BLUETOOTH_SERVICE);adapter=m==null?null:m.getAdapter();}
    BluetoothAdapter adapter(){return adapter;} boolean isReady(){return ready;} boolean isScanning(){return scanning;} String connectedName(){return name;} String connectedAddress(){return address;}

    @SuppressLint("MissingPermission") void startScan(){if(adapter==null){status("Bluetooth unavailable");return;}if(scanning||ready)return;scanner=adapter.getBluetoothLeScanner();if(scanner==null){status("BLE scanner unavailable");return;}scanning=true;status("Scanning for R2-D2…");log("Scanning for Kipps / 2ndHeroD.");scanner.startScan(null,new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),scanCb);h.postDelayed(scanTimeout,SCAN_TIMEOUT);}
    private void scanTimedOut(){if(!scanning)return;stopScan();status("R2-D2 not found");log("Scan timed out.");}
    @SuppressLint("MissingPermission") private void stopScan(){if(!scanning)return;scanning=false;h.removeCallbacks(scanTimeout);try{if(scanner!=null)scanner.stopScan(scanCb);}catch(SecurityException e){log(e.getMessage());}}
    private boolean matches(String n){if(n==null)return false;for(String p:Protocol.DEVICE_PREFIXES)if(n.startsWith(p))return true;return false;}
    private final ScanCallback scanCb=new ScanCallback(){@Override @SuppressLint("MissingPermission") public void onScanResult(int t,ScanResult r){BluetoothDevice d=r.getDevice();String n=d.getName();if(n==null&&r.getScanRecord()!=null)n=r.getScanRecord().getDeviceName();if(!matches(n))return;stopScan();name=n==null?"R2-D2":n;address=d.getAddress();callback.onDevice(name,address);status("Connecting…");log("Found "+name+" at "+address);gatt=d.connectGatt(context,false,gattCb,BluetoothDevice.TRANSPORT_LE);}@Override public void onScanFailed(int e){scanning=false;status("Bluetooth search failed");log("BLE scan error "+e);}};

    private final BluetoothGattCallback gattCb=new BluetoothGattCallback(){
        @Override @SuppressLint("MissingPermission") public void onConnectionStateChange(BluetoothGatt bg,int status,int state){if(state==BluetoothProfile.STATE_CONNECTED){gatt=bg;log("BLE connected; discovering services.");if(!bg.requestMtu(512))bg.discoverServices();}else if(state==BluetoothProfile.STATE_DISCONNECTED){log("Disconnected status "+status);close(bg);markDisconnected();}}
        @Override @SuppressLint("MissingPermission") public void onMtuChanged(BluetoothGatt bg,int mtu,int status){log("MTU "+mtu);bg.discoverServices();}
        @Override @SuppressLint("MissingPermission") public void onServicesDiscovered(BluetoothGatt bg,int status){if(status!=BluetoothGatt.GATT_SUCCESS){disconnect();return;}BluetoothGattService s=bg.getService(Protocol.SERVICE_UUID);if(s==null){log("R2-D2 service missing");disconnect();return;}write=s.getCharacteristic(Protocol.WRITE_UUID);BluetoothGattCharacteristic notify=s.getCharacteristic(Protocol.NOTIFY_UUID);if(write==null){disconnect();return;}if(notify!=null)enableNotify(bg,notify);ready=true;status("R2-D2 READY");callback.onConnected(true);startLoops();send(Protocol.KEEP_ALIVE);drain();}
        @Override public void onCharacteristicChanged(BluetoothGatt bg,BluetoothGattCharacteristic c){byte[] v=c.getValue();if(v!=null)receive(v);}
        @Override public void onCharacteristicChanged(BluetoothGatt bg,BluetoothGattCharacteristic c,byte[] value){receive(value);}
        @Override public void onReadRemoteRssi(BluetoothGatt bg,int value,int status){if(status==BluetoothGatt.GATT_SUCCESS)callback.onRssi(value);}
        @Override public void onCharacteristicWrite(BluetoothGatt bg,BluetoothGattCharacteristic c,int status){if(status!=BluetoothGatt.GATT_SUCCESS)log("Write failed "+status);}
    };
    private void receive(byte[] value){byte[] copy=value.clone();log("RX  "+Protocol.hex(copy));callback.onPacket(copy);}
    @SuppressLint("MissingPermission") private void enableNotify(BluetoothGatt bg,BluetoothGattCharacteristic c){if(!bg.setCharacteristicNotification(c,true)){log("Notify enable failed");return;}BluetoothGattDescriptor d=c.getDescriptor(Protocol.CCCD_UUID);if(d==null)return;if(Build.VERSION.SDK_INT>=33)bg.writeDescriptor(d,BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);else{d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);bg.writeDescriptor(d);}}
    private void startLoops(){stopLoops();keepAlive=new Runnable(){public void run(){if(!ready)return;sendSilent(Protocol.KEEP_ALIVE);h.postDelayed(this,KEEPALIVE);}};h.postDelayed(keepAlive,KEEPALIVE);rssiPoll=new Runnable(){@SuppressLint("MissingPermission") public void run(){if(!ready||gatt==null)return;try{gatt.readRemoteRssi();}catch(SecurityException ignored){}h.postDelayed(this,RSSI);}};h.postDelayed(rssiPoll,1000);}
    private void stopLoops(){if(keepAlive!=null)h.removeCallbacks(keepAlive);if(rssiPoll!=null)h.removeCallbacks(rssiPoll);keepAlive=null;rssiPoll=null;}
    synchronized boolean send(byte[] data){boolean result=sendInternal(data);if(!Arrays.equals(data,Protocol.KEEP_ALIVE))log("TX  "+Protocol.hex(data));return result;}
    private synchronized boolean sendSilent(byte[] d){return sendInternal(d);}
    private boolean sendInternal(byte[] data){if(!ready||gatt==null||write==null){if(pending.size()<64)pending.add(data.clone());return false;}try{if(Build.VERSION.SDK_INT>=33)return gatt.writeCharacteristic(write,data,BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)==BluetoothStatusCodes.SUCCESS;write.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);write.setValue(data);return gatt.writeCharacteristic(write);}catch(SecurityException e){log("Write permission: "+e.getMessage());return false;}}
    private synchronized void drain(){while(ready&&!pending.isEmpty()){byte[] d=pending.poll();if(d!=null)send(d);}}
    @SuppressLint("MissingPermission") void disconnect(){stopScan();stopLoops();ready=false;pending.clear();write=null;BluetoothGatt x=gatt;gatt=null;if(x!=null)try{x.disconnect();x.close();}catch(Exception ignored){}markDisconnected();}
    private void close(BluetoothGatt bg){try{bg.close();}catch(Exception ignored){}if(gatt==bg)gatt=null;write=null;}
    private void markDisconnected(){ready=false;stopLoops();status("Not connected");callback.onConnected(false);}
    private void status(String s){callback.onStatus(s);}private void log(String s){AppLog.add(s);callback.onLog(s);}
    String diagnostics(){return String.format(Locale.US,"ready=%s scanning=%s device=%s address=%s service=%s write=%s notify=%s",ready,scanning,name,address,Protocol.SERVICE_UUID,Protocol.WRITE_UUID,Protocol.NOTIFY_UUID);}
}
