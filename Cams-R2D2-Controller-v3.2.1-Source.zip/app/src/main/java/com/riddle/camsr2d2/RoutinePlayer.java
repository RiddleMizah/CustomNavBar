package com.riddle.camsr2d2;

import android.os.Handler;
import android.os.Looper;

final class RoutinePlayer {
    interface Executor { void execute(RoutineStep step, Runnable complete); void emergencyStop(); }
    interface Listener { void onRoutineStarted(Routine routine); void onRoutineStep(Routine routine,int index,RoutineStep step); void onRoutineFinished(Routine routine,boolean cancelled); }
    private final Handler h=new Handler(Looper.getMainLooper()); private final Executor executor; private final Listener listener;
    private Routine current; private int index, repeatIndex; private boolean cancelled;
    RoutinePlayer(Executor e,Listener l){executor=e;listener=l;}
    boolean isPlaying(){return current!=null;}
    void play(Routine r){stop();current=r;index=0;repeatIndex=0;cancelled=false;listener.onRoutineStarted(r);next();}
    void stop(){if(current==null)return;cancelled=true;h.removeCallbacksAndMessages(null);executor.emergencyStop();Routine r=current;current=null;listener.onRoutineFinished(r,true);}
    private void next(){Routine r=current;if(r==null||cancelled)return;if(index>=r.steps.size()){current=null;executor.emergencyStop();listener.onRoutineFinished(r,false);return;}
        RoutineStep s=r.steps.get(index);int i=index;h.postDelayed(()->{if(current!=r||cancelled)return;listener.onRoutineStep(r,i,s);executor.execute(s,()->{if(current!=r||cancelled)return;repeatIndex++;if(repeatIndex>=s.repeat){repeatIndex=0;index++;}next();});},repeatIndex==0?s.delayBeforeMs:120L);}
}
