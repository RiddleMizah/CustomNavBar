package com.riddle.camsr2d2;
import android.os.SystemClock;import java.util.ArrayList;import java.util.List;
final class RoutineRecorder{
 private final List<RoutineStep> steps=new ArrayList<>();private boolean recording;private long last;private ActionType pending;private long started,delay;
 void start(){steps.clear();recording=true;last=SystemClock.elapsedRealtime();pending=null;}boolean isRecording(){return recording;}int stepCount(){return steps.size()+(pending==null?0:1);}
 void recordAction(ActionType a){if(!recording||a.motion)return;long n=SystemClock.elapsedRealtime();steps.add(new RoutineStep(a,n-last,0));last=n;}
 void recordPacket(String label,byte[] packet){if(!recording)return;long n=SystemClock.elapsedRealtime();steps.add(RoutineStep.packet(label,packet,n-last,300));last=n;}
 void startMotion(ActionType a){if(!recording||!a.motion)return;if(pending!=null)stopMotion();long n=SystemClock.elapsedRealtime();pending=a;started=n;delay=n-last;}
 void stopMotion(){if(!recording||pending==null)return;long n=SystemClock.elapsedRealtime();steps.add(new RoutineStep(pending,delay,Math.max(150,n-started)));pending=null;last=n;}
 List<RoutineStep> finish(){if(pending!=null)stopMotion();recording=false;return new ArrayList<>(steps);}void cancel(){recording=false;pending=null;steps.clear();}
}
