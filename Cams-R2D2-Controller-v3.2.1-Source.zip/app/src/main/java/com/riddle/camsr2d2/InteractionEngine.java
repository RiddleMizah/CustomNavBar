package com.riddle.camsr2d2;

import android.os.Handler;
import android.os.Looper;

final class InteractionEngine {
    interface Listener { void onInteractiveStatus(String message); }
    private final MotionController motion; private final CommandCatalog catalog; private final AppPreferences prefs; private final Listener listener;
    private final Handler h=new Handler(Looper.getMainLooper()); private long lastClap; private boolean voiceHeard;
    InteractionEngine(MotionController m,CommandCatalog c,AppPreferences p,Listener l){motion=m;catalog=c;prefs=p;listener=l;}
    void onPacket(byte[] data,RobotState state){if(data.length==0)return;int op=data[0]&0xFF;
        if(op==0x1B&&data.length>1){int e=data[1]&0xFF;if(e==1&&prefs.enabled("clap",false))clap();if(e==2&&prefs.enabled("talk",false)){voiceHeard=true;listener.onInteractiveStatus("Listening to you…");}if(e==3&&prefs.enabled("music",false))musicStart();if(e==5){if(voiceHeard&&prefs.enabled("talk",false)){voiceHeard=false;talkReply();}if(prefs.enabled("music",false))musicStop();}}
        if(op==0x16&&state.obstacleClose()&&prefs.enabled("guard",false))guardAlert();}
    private void clap(){long now=System.currentTimeMillis();if(now-lastClap<850){lastClap=0;listener.onInteractiveStatus("Double clap — dance!");CommandItem item=catalog.randomCategory("HLSequence");if(item!=null)motion.sendPacket(item.name,item.packet,false);}else{lastClap=now;listener.onInteractiveStatus("Clap heard");h.postDelayed(()->{if(lastClap!=0&&System.currentTimeMillis()-lastClap>=800){lastClap=0;motion.performAction(ActionType.WHISTLE,false);motion.performAction(Math.random()<.5?ActionType.HEAD_LEFT:ActionType.HEAD_RIGHT,false);}},820);}}
    private void musicStart(){listener.onInteractiveStatus("Music detected — dance mode");motion.performAction(ActionType.LIGHT_BLUE,false);CommandItem item=catalog.randomCategory("MotorSequence");if(item!=null)motion.sendPacket(item.name,item.packet,false);}
    private void musicStop(){listener.onInteractiveStatus("Music stopped");motion.emergencyStop();motion.performAction(ActionType.LIGHTS_OFF,false);}
    private void talkReply(){listener.onInteractiveStatus("R2-D2 replied");CommandItem item=catalog.randomCategory("PNum");if(item!=null)motion.sendPacket(item.name,item.packet,false);motion.performAction(Math.random()<.5?ActionType.HEAD_LEFT:ActionType.HEAD_RIGHT,false);}
    private void guardAlert(){listener.onInteractiveStatus("GUARD ALERT — movement detected");motion.performAction(ActionType.LIGHT_RED,false);CommandItem item=catalog.findByCategoryAndId("HLSequence",461);if(item!=null)motion.sendPacket(item.name,item.packet,false);else motion.performAction(ActionType.ACHIEVEMENT,false);}
}
