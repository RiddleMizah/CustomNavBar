package com.riddle.camsr2d2;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

final class MotionController implements RoutinePlayer.Executor {
    private static final long CAM_SETTLE=420, HEAD_SETTLE=360;
    private final Context context; private final R2D2Client client; private final RoutineRecorder recorder; private final RobotState state; private final AppPreferences prefs;
    private final Handler h=new Handler(Looper.getMainLooper()); private ActionType active; private Runnable pendingMotor,timer,safety;
    MotionController(Context c,R2D2Client cl,RoutineRecorder r,RobotState s,AppPreferences p){context=c;client=cl;recorder=r;state=s;prefs=p;}

    void startManual(ActionType a){if(!ready())return;cancelPending();active=a;recorder.startMotion(a);motionStart(a,null);armSafety();AppLog.add("Manual "+a.label);}
    void stopManual(){cancelPending();if(active!=null)recorder.stopMotion();active=null;sendStop();}
    void updateManual(ActionType a){
        if(a==null||a==ActionType.STOP){if(active!=null)stopManual();return;}
        if(active==a){armSafety();return;}
        if(active!=null)stopManual();
        startManual(a);
    }
    void performAction(ActionType a,boolean record){if(!client.isReady()&&a!=ActionType.STOP){toast("Connect R2-D2 first.");return;}if(record)recorder.recordAction(a);
        switch(a){case STOP:emergencyStop();break;case HEAD_LEFT:moveHead(Protocol.HEAD_LEFT);break;case HEAD_CENTER:moveHead(Protocol.HEAD_CENTER);break;case HEAD_RIGHT:moveHead(Protocol.HEAD_RIGHT);break;
            case LIGHT_RED:send(Protocol.led(255,0));break;case LIGHT_BLUE:send(Protocol.led(0,255));break;case LIGHTS_OFF:send(Protocol.led(0,0));break;
            case WAKE:send(Protocol.audio(Protocol.AUDIO_WAKE));break;case WHISTLE:send(Protocol.audio(Protocol.AUDIO_WHISTLE));break;case ACHIEVEMENT:send(Protocol.audio(Protocol.AUDIO_ACHIEVEMENT));break;case CANTINA:send(Protocol.audio(Protocol.AUDIO_CANTINA));break;default:break;}}

    void moveHead(int target){RobotState.Head wanted=target==0?RobotState.Head.LEFT:target==2?RobotState.Head.RIGHT:RobotState.Head.CENTER;
        if(state.head==wanted && target!=Protocol.HEAD_CENTER){send(Protocol.head(Protocol.HEAD_CENTER));state.predictHead(Protocol.HEAD_CENTER);h.postDelayed(()->{send(Protocol.head(target));state.predictHead(target);},HEAD_SETTLE);AppLog.add("Head was already "+wanted+"; centered before repeating.");}
        else{send(Protocol.head(target));state.predictHead(target);}}

    void sendPacket(String label,byte[] packet,boolean record){if(!ready())return;send(packet);if(record)recorder.recordPacket(label,packet);}
    void setLed(int red,int blue){send(Protocol.led(red,blue));}
    void playAudio(int id){send(Protocol.audio(id));}
    void playSequence(int type,int id){send(Protocol.sequence(type,id));}
    void stopAudio(){send(Protocol.stopAudio());}
    void powerDown(){if(client.isReady()){send(Protocol.KEEP_ALIVE);h.postDelayed(()->send(Protocol.POWER_DOWN),80);}}

    void spin180(boolean left,boolean fast,Runnable done){if(!ready()){if(done!=null)done.run();return;}long duration=fast?Math.max(500,prefs.spin180Ms()-250):prefs.spin180Ms();ActionType action=left?ActionType.TURN_LEFT:ActionType.TURN_RIGHT;motionStart(action,()->{timer=()->{sendStop();timer=null;if(done!=null)done.run();};h.postDelayed(timer,duration);});}

    private void motionStart(ActionType a,Runnable begun){int cam,dir;switch(a){case FORWARD:cam=Protocol.CAM_DRIVE;dir=Protocol.MOTOR_FORWARD;break;case REVERSE:cam=Protocol.CAM_DRIVE;dir=Protocol.MOTOR_BACKWARD;break;case TURN_LEFT:cam=Protocol.CAM_PIVOT_LEFT;dir=Protocol.MOTOR_FORWARD;break;case TURN_RIGHT:cam=Protocol.CAM_PIVOT_RIGHT;dir=Protocol.MOTOR_FORWARD;break;default:return;}
        boolean already=(cam==Protocol.CAM_DRIVE&&state.body==RobotState.Body.DRIVE)||(cam==Protocol.CAM_PIVOT_LEFT&&state.body==RobotState.Body.PIVOT_LEFT)||(cam==Protocol.CAM_PIVOT_RIGHT&&state.body==RobotState.Body.PIVOT_RIGHT);
        if(!already){send(Protocol.cam(cam));state.predictBody(cam);}pendingMotor=()->{pendingMotor=null;send(Protocol.motor(dir));if(begun!=null)begun.run();};h.postDelayed(pendingMotor,already?80:CAM_SETTLE);}
    private void armSafety(){if(safety!=null)h.removeCallbacks(safety);safety=()->{if(active!=null){active=null;sendStop();toast("Drive safety timeout stopped R2-D2.");}};h.postDelayed(safety,prefs.maxDriveSeconds()*1000L);}
    private void cancelPending(){if(pendingMotor!=null)h.removeCallbacks(pendingMotor);if(timer!=null)h.removeCallbacks(timer);if(safety!=null)h.removeCallbacks(safety);pendingMotor=timer=safety=null;}
    private void sendStop(){if(client.isReady()){send(Protocol.motor(Protocol.MOTOR_STOP));send(Protocol.stopAll());}}
    private void send(byte[] p){client.send(p);}private boolean ready(){if(!client.isReady()){toast("Connect R2-D2 first.");return false;}return true;}

    @Override public void execute(RoutineStep s,Runnable complete){if(s.kind==RoutineStep.Kind.WAIT){h.postDelayed(complete,Math.max(1,s.durationMs));return;}if(s.kind==RoutineStep.Kind.PACKET){sendPacket(s.label,s.packet,false);h.postDelayed(complete,Math.max(180,s.durationMs));return;}if(s.isMotion()){motionStart(s.action,()->{timer=()->{sendStop();timer=null;complete.run();};h.postDelayed(timer,Math.max(150,s.durationMs));});}else{performAction(s.action,false);h.postDelayed(complete,Math.max(240,s.durationMs));}}
    @Override public void emergencyStop(){cancelPending();active=null;sendStop();AppLog.add("Emergency stop sent.");}
    private void toast(String s){Toast.makeText(context,s,Toast.LENGTH_SHORT).show();}
}
