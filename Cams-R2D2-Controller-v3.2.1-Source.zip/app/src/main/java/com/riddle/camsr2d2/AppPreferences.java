package com.riddle.camsr2d2;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;

final class AppPreferences {
    private static final String PREFS = "r2d2_controller_settings_v3";
    private final SharedPreferences p;
    AppPreferences(Context context) { p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    String controllerName() { return normalize(p.getString("controller_name", BuildConfig.DEFAULT_CONTROLLER_NAME)); }
    void setControllerName(String value) { p.edit().putString("controller_name", normalize(value)).apply(); }
    String possessiveName() { String n=controllerName(); return n.toLowerCase(Locale.US).endsWith("s") ? n+"'" : n+"'s"; }
    String controllerTitle() { return possessiveName() + " R2-D2 Command Center"; }

    boolean enabled(String key, boolean def) { return p.getBoolean("feature_" + key, def); }
    void setEnabled(String key, boolean value) { p.edit().putBoolean("feature_" + key, value).apply(); }
    int tiltDeadzone() { return p.getInt("tilt_deadzone", 12); }
    void setTiltDeadzone(int value) { p.edit().putInt("tilt_deadzone", value).apply(); }
    int tiltSensitivity() { return p.getInt("tilt_sensitivity", 55); }
    void setTiltSensitivity(int value) { p.edit().putInt("tilt_sensitivity", value).apply(); }
    int maxDriveSeconds() { return p.getInt("max_drive_seconds", 8); }
    void setMaxDriveSeconds(int value) { p.edit().putInt("max_drive_seconds", value).apply(); }
    int spin180Ms() { return p.getInt("spin_180_ms", 1200); }
    void setSpin180Ms(int value) { p.edit().putInt("spin_180_ms", value).apply(); }
    String voicePhrase(String key, String def) { return p.getString("voice_"+key, def); }
    void setVoicePhrase(String key, String value) { p.edit().putString("voice_"+key, value.trim()).apply(); }

    private String normalize(String value) {
        String result = value == null ? "" : value.trim().replaceAll("\\s+", " ");
        if (result.isEmpty()) result = "Cam";
        return result.length() > 24 ? result.substring(0,24).trim() : result;
    }
}
