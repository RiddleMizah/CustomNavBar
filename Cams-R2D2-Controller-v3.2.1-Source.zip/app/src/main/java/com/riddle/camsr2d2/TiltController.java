package com.riddle.camsr2d2;

import android.content.Context;
import android.hardware.*;

final class TiltController implements SensorEventListener {
    interface Listener { void onTilt(float x,float y,String action); }
    private final SensorManager manager; private final Sensor sensor; private final MotionController motion; private final AppPreferences prefs; private final Listener listener;
    private boolean enabled; private float baseX,baseY; private boolean calibrated; private ActionType current;
    TiltController(Context c,MotionController m,AppPreferences p,Listener l){manager=(SensorManager)c.getSystemService(Context.SENSOR_SERVICE);sensor=manager==null?null:manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);motion=m;prefs=p;listener=l;}
    boolean available(){return sensor!=null;}
    void calibrate(){calibrated=false;}
    void start(){if(sensor==null)return;enabled=true;manager.registerListener(this,sensor,SensorManager.SENSOR_DELAY_GAME);}
    void stop(){enabled=false;if(manager!=null)manager.unregisterListener(this);if(current!=null)motion.stopManual();current=null;listener.onTilt(0,0,"SAFE / STOPPED");}
    @Override public void onSensorChanged(SensorEvent e){if(!enabled)return;float x=e.values[0],y=e.values[1];if(!calibrated){baseX=x;baseY=y;calibrated=true;listener.onTilt(0,0,"CALIBRATED");return;}float dx=x-baseX,dy=y-baseY;float threshold=0.8f+(prefs.tiltDeadzone()/100f)*3.0f;ActionType next=null;
        if(Math.abs(dy)>Math.abs(dx)&&Math.abs(dy)>threshold)next=dy<0?ActionType.FORWARD:ActionType.REVERSE;else if(Math.abs(dx)>threshold)next=dx>0?ActionType.TURN_LEFT:ActionType.TURN_RIGHT;
        if(next!=current){if(current!=null)motion.stopManual();current=next;if(next!=null)motion.startManual(next);}listener.onTilt(dx,dy,next==null?"DEAD ZONE":next.label.toUpperCase());}
    @Override public void onAccuracyChanged(Sensor s,int a){}
}
