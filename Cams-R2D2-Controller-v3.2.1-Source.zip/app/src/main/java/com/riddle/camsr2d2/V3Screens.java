package com.riddle.camsr2d2;

import android.graphics.Color;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class V3Screens {
    private static TextView tiltReadout;
    private static TextView tiltVector;
    private static TextView gamepadStatusView;
    private static TextView gamepadInputView;

    private V3Screens() {}

    private static LinearLayout base(MainActivity activity, String title, String subtitle) {
        LinearLayout page = Ui.page(activity);
        page.addView(Ui.text(activity, title, 29, true, Ui.INK));
        page.addView(Ui.text(activity, subtitle, 14, false, Ui.MUTED), Ui.matchWrap(activity, 0, 4, 0, 12));
        return page;
    }

    private static Button small(MainActivity activity, String title, String color, Runnable action) {
        Button button = Ui.button(activity, title, color, Ui.WHITE, 14);
        button.setOnClickListener(v -> action.run());
        return button;
    }

    private static Button small(MainActivity activity, String title, Runnable action) {
        return small(activity, title, Ui.BLUE, action);
    }

    private static LinearLayout buttons(MainActivity activity, Button... buttons) {
        LinearLayout row = new LinearLayout(activity);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for (Button button : buttons) row.addView(button, Ui.weightedButton(activity));
        return row;
    }

    private static TextView status(MainActivity activity, String title, String color) {
        TextView view = Ui.text(activity, title, 16, true, Ui.WHITE);
        view.setGravity(Gravity.CENTER);
        view.setPadding(Ui.dp(activity, 12), Ui.dp(activity, 11), Ui.dp(activity, 12), Ui.dp(activity, 11));
        view.setBackground(Ui.round(activity, color, 16));
        return view;
    }

    static View home(MainActivity activity) {
        LinearLayout page = base(activity, "What should R2-D2 do?", "Big buttons, simple choices, and all the powerful controls still underneath.");

        LinearLayout hero = Ui.section(activity,
                activity.isR2Ready() ? "R2-D2 is ready!" : "Let’s wake up R2-D2",
                activity.isR2Ready() ? "Connected and waiting for a command." : "Turn on R2-D2, then tap Connect.");
        hero.addView(status(activity, activity.latestStatus, activity.isR2Ready() ? Ui.GREEN : "#8199AA"));
        hero.addView(buttons(activity,
                small(activity, activity.isR2Ready() ? "Disconnect" : "Connect", Ui.BLUE,
                        () -> { if (activity.isR2Ready()) activity.disconnectR2D2(); else activity.requestConnection(); }),
                small(activity, "Surprise Me!", Ui.PURPLE, activity::playRandomDance),
                small(activity, "STOP R2-D2", Ui.RED, activity::emergencyStop)),
                Ui.matchWrap(activity, 0, 10, 0, 0));
        page.addView(hero, Ui.matchWrap(activity, 0, 0, 0, 10));

        GridLayout grid = new GridLayout(activity);
        grid.setColumnCount(3);
        grid.addView(tile(activity, "🎮", "DRIVE", "Move, turn, and control his head", Ui.BLUE,
                () -> activity.showScreen(MainActivity.DRIVE)), Ui.gridCell(activity));
        if (activity.prefs().enabled("controller", true)) {
            grid.addView(tile(activity, "🕹", "CONTROLLER MODE", "Use a Nintendo Switch or Android gamepad", Ui.NAVY,
                    () -> activity.showScreen(MainActivity.REMOTE)), Ui.gridCell(activity));
        }
        if (activity.prefs().enabled("games", true)) {
            grid.addView(tile(activity, "★", "GAMES", "Seven games to play together", Ui.GREEN,
                    () -> activity.showScreen(MainActivity.GAMES)), Ui.gridCell(activity));
        }
        grid.addView(tile(activity, "♫", "DANCES", "Dances, spins, and silly moves", Ui.PURPLE,
                () -> activity.showScreen(MainActivity.DANCES)), Ui.gridCell(activity));
        grid.addView(tile(activity, "🔊", "SOUNDS", "Beeps, whistles, and R2 chatter", Ui.ORANGE,
                () -> activity.showScreen(MainActivity.ACTIONS)), Ui.gridCell(activity));
        grid.addView(tile(activity, "✦", "LIGHTS", "Colors and flashing light effects", "#E8A900",
                () -> activity.showScreen(MainActivity.LIGHTS)), Ui.gridCell(activity));
        grid.addView(tile(activity, "🧩", "BUILD A ROUTINE", "Record or snap actions together", Ui.TEAL,
                () -> activity.showScreen(MainActivity.STUDIO)), Ui.gridCell(activity));
        if (activity.prefs().enabled("tilt", true)) {
            grid.addView(tile(activity, "↗", "TILT DRIVE", "Tilt the tablet to steer", "#4E9D65",
                    () -> activity.showScreen(MainActivity.TILT)), Ui.gridCell(activity));
        }
        if (activity.prefs().enabled("voice", true)) {
            grid.addView(tile(activity, "🎤", "VOICE COMMANDS", "Tell R2-D2 what to do", "#D85A7F",
                    () -> activity.showScreen(MainActivity.VOICE)), Ui.gridCell(activity));
        }
        grid.addView(tile(activity, "◉", "INTERACTIVE", "Clap, music, talk, and guard modes", "#5C75C8",
                () -> activity.showScreen(MainActivity.INTERACTIVE)), Ui.gridCell(activity));
        page.addView(grid);

        Button parent = Ui.button(activity, "Hold for Parent Mode", "#DCEAF3", Ui.INK, 13);
        parent.setOnClickListener(v -> activity.toastMessage("Press and hold for Parent Mode"));
        parent.setOnLongClickListener(v -> { activity.showScreen(MainActivity.PARENT); return true; });
        page.addView(parent, Ui.matchWrap(activity, 7, 14, 7, 0));
        return Ui.scrollPage(activity, page);
    }

    private static View tile(MainActivity activity, String icon, String title, String subtitle,
                             String color, Runnable action) {
        LinearLayout card = Ui.card(activity, Ui.WHITE);
        card.setPadding(Ui.dp(activity, 15), Ui.dp(activity, 12), Ui.dp(activity, 15), Ui.dp(activity, 14));
        card.setGravity(Gravity.CENTER);
        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> action.run());

        TextView iconView = Ui.text(activity, icon, 31, true, color);
        iconView.setGravity(Gravity.CENTER);
        card.addView(iconView);

        TextView titleView = Ui.text(activity, title, 18, true, color);
        titleView.setGravity(Gravity.CENTER);
        card.addView(titleView, Ui.matchWrap(activity, 0, 4, 0, 0));

        TextView subtitleView = Ui.text(activity, subtitle, 12, false, Ui.MUTED);
        subtitleView.setGravity(Gravity.CENTER);
        card.addView(subtitleView, Ui.matchWrap(activity, 0, 5, 0, 10));

        Button open = Ui.button(activity, "OPEN", color, Ui.WHITE, 13);
        open.setOnClickListener(v -> action.run());
        card.addView(open, new LinearLayout.LayoutParams(-1, Ui.dp(activity, 42)));
        return card;
    }

    static View drive(MainActivity activity) {
        LinearLayout page = base(activity, "Drive R2-D2", "Hold a direction button to move. Let go and he stops right away.");

        LinearLayout drive = Ui.section(activity, "Big Drive Pad",
                "Movement automatically stops after " + activity.prefs().maxDriveSeconds() + " seconds for safety.");
        GridLayout pad = new GridLayout(activity);
        pad.setColumnCount(3);
        Ui.addGridSpacer(activity, pad);
        pad.addView(hold(activity, "▲\nFORWARD", ActionType.FORWARD), Ui.fixedGridCell(activity, 92));
        Ui.addGridSpacer(activity, pad);
        pad.addView(hold(activity, "◀\nTURN LEFT", ActionType.TURN_LEFT), Ui.fixedGridCell(activity, 92));
        Button stop = Ui.bigButton(activity, "■\nSTOP", Ui.RED);
        stop.setOnClickListener(v -> activity.emergencyStop());
        pad.addView(stop, Ui.fixedGridCell(activity, 92));
        pad.addView(hold(activity, "TURN RIGHT\n▶", ActionType.TURN_RIGHT), Ui.fixedGridCell(activity, 92));
        Ui.addGridSpacer(activity, pad);
        pad.addView(hold(activity, "▼\nBACK UP", ActionType.REVERSE), Ui.fixedGridCell(activity, 92));
        Ui.addGridSpacer(activity, pad);
        drive.addView(pad);
        Button allStop = Ui.button(activity, "EMERGENCY STOP — STOP EVERYTHING", Ui.RED, Ui.WHITE, 17);
        allStop.setOnClickListener(v -> activity.emergencyStop());
        drive.addView(allStop, new LinearLayout.LayoutParams(-1, Ui.dp(activity, 54)));
        page.addView(drive);

        LinearLayout head = Ui.section(activity, "Move R2-D2’s Head",
                "If his head is already left or right, the app centers it first before repeating that direction.");
        head.addView(buttons(activity,
                small(activity, "◀ LEFT", Ui.BLUE, () -> activity.performAction(ActionType.HEAD_LEFT, true)),
                small(activity, "● CENTER", Ui.TEAL, () -> activity.performAction(ActionType.HEAD_CENTER, true)),
                small(activity, "RIGHT ▶", Ui.BLUE, () -> activity.performAction(ActionType.HEAD_RIGHT, true))));
        page.addView(head, Ui.matchWrap(activity, 0, 10, 0, 0));

        LinearLayout quick = Ui.section(activity, "Quick Fun", "Lights and sounds without leaving the drive screen.");
        quick.addView(buttons(activity,
                small(activity, "BLUE LIGHT", Ui.BLUE, () -> activity.performAction(ActionType.LIGHT_BLUE, true)),
                small(activity, "RED LIGHT", Ui.RED, () -> activity.performAction(ActionType.LIGHT_RED, true)),
                small(activity, "LIGHTS OFF", "#6D8292", () -> activity.performAction(ActionType.LIGHTS_OFF, true))));
        quick.addView(buttons(activity,
                small(activity, "WAKE UP", Ui.ORANGE, () -> activity.performAction(ActionType.WAKE, true)),
                small(activity, "WHISTLE", Ui.PURPLE, () -> activity.performAction(ActionType.WHISTLE, true)),
                small(activity, "CELEBRATE", Ui.GREEN, () -> activity.performAction(ActionType.ACHIEVEMENT, true))),
                Ui.matchWrap(activity, 0, 9, 0, 0));
        page.addView(quick, Ui.matchWrap(activity, 0, 10, 0, 0));

        LinearLayout record = Ui.section(activity, "Make Your Own Drive Routine",
                activity.isRecording() ? "Recording every move. Tap Finish when you are done."
                        : "Record the buttons you press, then replay them later.");
        record.addView(small(activity,
                activity.isRecording() ? "FINISH RECORDING" : "START RECORDING",
                activity.isRecording() ? Ui.RED : Ui.TEAL,
                activity.isRecording() ? activity::finishRecording : activity::startRecording),
                new LinearLayout.LayoutParams(-1, Ui.dp(activity, 52)));
        page.addView(record, Ui.matchWrap(activity, 0, 10, 0, 0));
        return Ui.scrollPage(activity, page);
    }

    private static Button hold(MainActivity activity, String title, ActionType action) {
        Button button = Ui.bigButton(activity, title, Ui.BLUE);
        button.setOnTouchListener((view, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                activity.startManualMotion(action);
                return true;
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP
                    || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                activity.stopManualMotion();
                view.performClick();
                return true;
            }
            return false;
        });
        return button;
    }

    static View remote(MainActivity activity) {
        LinearLayout page = base(activity, "Controller Mode",
                "Pair the controller to Android first. While this screen is open, the gamepad is armed; leaving the screen stops movement.");

        LinearLayout state = Ui.section(activity, "Connected Controller", "Works with Nintendo Switch-style and standard Android gamepads.");
        gamepadStatusView = status(activity, activity.gamepadStatus,
                activity.gamepad().deviceName().startsWith("No ") ? "#8199AA" : Ui.GREEN);
        gamepadInputView = Ui.text(activity, activity.gamepadInput, 14, true, Ui.NAVY);
        gamepadInputView.setGravity(Gravity.CENTER);
        state.addView(gamepadStatusView, new LinearLayout.LayoutParams(-1, Ui.dp(activity, 52)));
        state.addView(gamepadInputView, Ui.matchWrap(activity, 0, 9, 0, 0));
        state.addView(small(activity, "EMERGENCY STOP", Ui.RED, activity::emergencyStop),
                Ui.matchWrap(activity, 0, 10, 0, 0));
        page.addView(state);

        LinearLayout sticks = Ui.section(activity, "Sticks", "R2-D2 only exposes discrete drive/pivot positions, so stick direction selects the closest supported movement.");
        sticks.addView(Ui.text(activity, "LEFT STICK  •  Forward / Reverse / Pivot Left / Pivot Right", 15, true, Ui.INK));
        sticks.addView(Ui.text(activity, "RIGHT STICK  •  Head Left / Center / Right", 15, true, Ui.INK), Ui.matchWrap(activity, 0, 8, 0, 0));
        sticks.addView(Ui.text(activity, "Right stick click  •  Center head", 13, false, Ui.MUTED), Ui.matchWrap(activity, 0, 7, 0, 0));
        page.addView(sticks, Ui.matchWrap(activity, 0, 10, 0, 0));

        LinearLayout face = Ui.section(activity, "Nintendo Face Buttons", "Android maps by physical button position; these labels match the Switch layout.");
        GridLayout faceGrid = new GridLayout(activity); faceGrid.setColumnCount(2);
        faceGrid.addView(mapCard(activity, "B  •  bottom", "Whistle", Ui.PURPLE), Ui.gridCell(activity));
        faceGrid.addView(mapCard(activity, "A  •  right", "Celebrate", Ui.GREEN), Ui.gridCell(activity));
        faceGrid.addView(mapCard(activity, "Y  •  left", "Wake Up", Ui.ORANGE), Ui.gridCell(activity));
        faceGrid.addView(mapCard(activity, "X  •  top", "Cantina Song", Ui.BLUE), Ui.gridCell(activity));
        face.addView(faceGrid); page.addView(face, Ui.matchWrap(activity, 0, 10, 0, 0));

        LinearLayout extras = Ui.section(activity, "Shoulders, Triggers, and D-pad", "Extra actions stay available without touching the tablet.");
        extras.addView(Ui.text(activity, "L = Blue light     •     R = Red light", 14, true, Ui.INK));
        extras.addView(Ui.text(activity, "ZL = Lights off     •     ZR = Random R2 sound", 14, true, Ui.INK), Ui.matchWrap(activity, 0, 7, 0, 0));
        extras.addView(Ui.text(activity, "+ = EMERGENCY STOP     •     − = Stop sounds", 14, true, Ui.INK), Ui.matchWrap(activity, 0, 7, 0, 0));
        extras.addView(Ui.text(activity, "D-pad ↑ Random dance   ↓ Stop sounds   ← Cantina Part 2   → R2 chatter", 13, false, Ui.MUTED), Ui.matchWrap(activity, 0, 7, 0, 0));
        page.addView(extras, Ui.matchWrap(activity, 0, 10, 0, 0));
        return Ui.scrollPage(activity, page);
    }

    private static View mapCard(MainActivity activity, String control, String action, String color) {
        LinearLayout card = Ui.card(activity, Ui.WHITE);
        card.setPadding(Ui.dp(activity, 13), Ui.dp(activity, 10), Ui.dp(activity, 13), Ui.dp(activity, 10));
        TextView c = Ui.text(activity, control, 15, true, color); c.setGravity(Gravity.CENTER); card.addView(c);
        TextView a = Ui.text(activity, action, 13, false, Ui.INK); a.setGravity(Gravity.CENTER); card.addView(a, Ui.matchWrap(activity, 0, 5, 0, 0));
        return card;
    }

    static void updateGamepad(MainActivity activity) {
        if (gamepadStatusView != null && gamepadStatusView.isAttachedToWindow()) gamepadStatusView.setText(activity.gamepadStatus);
        if (gamepadInputView != null && gamepadInputView.isAttachedToWindow()) gamepadInputView.setText(activity.gamepadInput);
    }

    static View tilt(MainActivity activity) {
        LinearLayout page = base(activity, "Tilt Drive", "Hold the big green button, then gently tilt the tablet to steer.");
        LinearLayout card = Ui.section(activity, "Tilt Steering",
                activity.tilt().available() ? "Tablet motion sensor ready." : "This tablet does not report an accelerometer.");
        tiltReadout = status(activity, activity.tiltStatus, Ui.NAVY);
        tiltVector = Ui.text(activity,
                String.format(Locale.US, "Left / Right %.2f     Forward / Back %.2f", activity.tiltX, activity.tiltY),
                17, true, Ui.NAVY);
        tiltVector.setGravity(Gravity.CENTER);
        card.addView(tiltReadout, new LinearLayout.LayoutParams(-1, Ui.dp(activity, 54)));
        card.addView(tiltVector, Ui.matchWrap(activity, 0, 12, 0, 12));

        Button arm = Ui.bigButton(activity, "HOLD TO DRIVE WITH TILT", Ui.GREEN);
        arm.setOnTouchListener((view, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                activity.tilt().start();
                return true;
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP
                    || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                activity.tilt().stop();
                view.performClick();
                return true;
            }
            return false;
        });
        card.addView(arm, new LinearLayout.LayoutParams(-1, Ui.dp(activity, 94)));
        card.addView(buttons(activity,
                small(activity, "Recenter Tablet", Ui.BLUE, activity.tilt()::calibrate),
                small(activity, "STOP", Ui.RED, activity.tilt()::stop)), Ui.matchWrap(activity, 0, 10, 0, 0));
        page.addView(card);
        return Ui.scrollPage(activity, page);
    }

    static void updateTilt(MainActivity activity) {
        if (tiltReadout != null) tiltReadout.setText(activity.tiltStatus);
        if (tiltVector != null) {
            tiltVector.setText(String.format(Locale.US,
                    "Left / Right %.2f     Forward / Back %.2f", activity.tiltX, activity.tiltY));
        }
    }

    static View actions(MainActivity activity) {
        LinearLayout page = base(activity, "R2-D2 Sounds", "Tap a big button and R2-D2 will choose a matching sound from his full sound library.");

        GridLayout grid = new GridLayout(activity);
        grid.setColumnCount(3);
        grid.addView(soundTile(activity, "♪", "HAPPY BEEPS", Ui.GREEN, () -> activity.playRandomSound("happy")), Ui.gridCell(activity));
        grid.addView(soundTile(activity, "!?", "SURPRISED", Ui.ORANGE, () -> activity.playRandomSound("surprise")), Ui.gridCell(activity));
        grid.addView(soundTile(activity, "☺", "SILLY R2", Ui.PURPLE, () -> activity.playRandomSound("")), Ui.gridCell(activity));
        grid.addView(soundTile(activity, "♫", "PLAY A TUNE", Ui.BLUE, () -> activity.playRandomSound("music")), Ui.gridCell(activity));
        grid.addView(soundTile(activity, "⚠", "ALERT SOUND", Ui.RED, () -> activity.playRandomSound("alert")), Ui.gridCell(activity));
        grid.addView(soundTile(activity, "…", "R2 CHATTER", Ui.TEAL, () -> activity.playRandomSound("talk")), Ui.gridCell(activity));
        page.addView(grid);

        LinearLayout favorites = Ui.section(activity, "Favorite Sounds", "Reliable quick sounds for younger players.");
        favorites.addView(buttons(activity,
                small(activity, "WAKE UP", Ui.ORANGE, () -> activity.performAction(ActionType.WAKE, false)),
                small(activity, "WHISTLE", Ui.PURPLE, () -> activity.performAction(ActionType.WHISTLE, false)),
                small(activity, "CELEBRATE", Ui.GREEN, () -> activity.performAction(ActionType.ACHIEVEMENT, false)),
                small(activity, "CANTINA", Ui.BLUE, activity::playCantina)));
        favorites.addView(buttons(activity,
                small(activity, "CANTINA PART 2", Ui.PURPLE, activity::playCantinaPart2),
                small(activity, "RANDOM CHATTER", Ui.TEAL, () -> activity.playRandomSound("talk"))),
                Ui.matchWrap(activity, 0, 9, 0, 0));
        favorites.addView(small(activity, "STOP ALL SOUNDS", Ui.RED, activity.motion()::stopAudio), Ui.matchWrap(activity, 5, 10, 5, 0));
        page.addView(favorites, Ui.matchWrap(activity, 0, 10, 0, 0));
        return Ui.scrollPage(activity, page);
    }

    private static View soundTile(MainActivity activity, String icon, String title, String color, Runnable action) {
        LinearLayout card = Ui.card(activity, Ui.WHITE);
        card.setPadding(Ui.dp(activity, 14), Ui.dp(activity, 12), Ui.dp(activity, 14), Ui.dp(activity, 14));
        TextView iconView = Ui.text(activity, icon, 30, true, color);
        iconView.setGravity(Gravity.CENTER);
        card.addView(iconView);
        TextView label = Ui.text(activity, title, 16, true, color);
        label.setGravity(Gravity.CENTER);
        card.addView(label, Ui.matchWrap(activity, 0, 5, 0, 9));
        Button play = Ui.button(activity, "PLAY", color, Ui.WHITE, 13);
        play.setOnClickListener(v -> action.run());
        card.addView(play, new LinearLayout.LayoutParams(-1, Ui.dp(activity, 44)));
        return card;
    }

    static View dances(MainActivity activity) {
        LinearLayout page = base(activity, "Dances and Routines", "Choose a dance, patrol, bedtime routine, or a random recovered animation.");
        GridLayout grid = new GridLayout(activity);
        grid.setColumnCount(3);
        String[] colors = {Ui.PURPLE, Ui.GREEN, Ui.BLUE, Ui.ORANGE, Ui.RED, Ui.TEAL};
        int index = 0;
        for (Routine routine : PresetRoutines.all()) {
            String color = colors[index++ % colors.length];
            grid.addView(routineTile(activity, routine, color), Ui.gridCell(activity));
        }
        page.addView(grid);

        LinearLayout random = Ui.section(activity, "Hundreds More R2-D2 Animations",
                "Surprise Dance selects one of the recovered high-level R2-D2 routines.");
        random.addView(small(activity, "SURPRISE DANCE!", Ui.PURPLE, activity::playRandomDance),
                new LinearLayout.LayoutParams(-1, Ui.dp(activity, 58)));
        random.addView(small(activity, "STOP DANCE", Ui.RED, activity::emergencyStop),
                Ui.matchWrap(activity, 0, 10, 0, 0));
        page.addView(random, Ui.matchWrap(activity, 0, 10, 0, 0));
        return Ui.scrollPage(activity, page);
    }

    private static View routineTile(MainActivity activity, Routine routine, String color) {
        LinearLayout card = Ui.card(activity, Ui.WHITE);
        card.setPadding(Ui.dp(activity, 14), Ui.dp(activity, 13), Ui.dp(activity, 14), Ui.dp(activity, 14));
        TextView title = Ui.text(activity, routine.name, 17, true, color);
        title.setGravity(Gravity.CENTER);
        card.addView(title);
        TextView detail = Ui.text(activity, routine.steps.size() + " fun actions", 12, false, Ui.MUTED);
        detail.setGravity(Gravity.CENTER);
        card.addView(detail, Ui.matchWrap(activity, 0, 5, 0, 10));
        Button play = Ui.button(activity, "PLAY", color, Ui.WHITE, 13);
        play.setOnClickListener(v -> activity.playRoutine(routine));
        card.addView(play, new LinearLayout.LayoutParams(-1, Ui.dp(activity, 44)));
        return card;
    }

    static View studio(MainActivity activity) {
        LinearLayout page = base(activity, "Build a Routine", "Record driving or tap colorful action blocks to make your own R2-D2 routine.");

        LinearLayout record = Ui.section(activity, "Fastest Way: Record It", "Start recording, drive R2-D2, then tap Finish.");
        record.addView(small(activity, activity.isRecording() ? "FINISH RECORDING" : "START RECORDING",
                activity.isRecording() ? Ui.RED : Ui.TEAL,
                activity.isRecording() ? activity::finishRecording : activity::startRecording),
                new LinearLayout.LayoutParams(-1, Ui.dp(activity, 56)));
        page.addView(record);

        LinearLayout builder = Ui.section(activity, "Routine Blocks", "Tap blocks in the order R2-D2 should do them.");
        GridLayout blocks = new GridLayout(activity);
        blocks.setColumnCount(4);
        addBlock(activity, blocks, "FORWARD", Ui.BLUE, new RoutineStep(ActionType.FORWARD, 0, 1000));
        addBlock(activity, blocks, "BACK UP", "#607D8B", new RoutineStep(ActionType.REVERSE, 0, 1000));
        addBlock(activity, blocks, "TURN LEFT", Ui.PURPLE, new RoutineStep(ActionType.TURN_LEFT, 0, 600));
        addBlock(activity, blocks, "TURN RIGHT", Ui.PURPLE, new RoutineStep(ActionType.TURN_RIGHT, 0, 600));
        addBlock(activity, blocks, "HEAD LEFT", Ui.BLUE, new RoutineStep(ActionType.HEAD_LEFT, 0, 0));
        addBlock(activity, blocks, "HEAD CENTER", Ui.TEAL, new RoutineStep(ActionType.HEAD_CENTER, 0, 0));
        addBlock(activity, blocks, "HEAD RIGHT", Ui.BLUE, new RoutineStep(ActionType.HEAD_RIGHT, 0, 0));
        addBlock(activity, blocks, "WAIT 1 SEC", Ui.YELLOW, RoutineStep.waitMs(1000));
        addBlock(activity, blocks, "BLUE LIGHT", Ui.BLUE, new RoutineStep(ActionType.LIGHT_BLUE, 0, 0));
        addBlock(activity, blocks, "RED LIGHT", Ui.RED, new RoutineStep(ActionType.LIGHT_RED, 0, 0));
        addBlock(activity, blocks, "LIGHTS OFF", "#718391", new RoutineStep(ActionType.LIGHTS_OFF, 0, 0));
        addBlock(activity, blocks, "WHISTLE", Ui.ORANGE, new RoutineStep(ActionType.WHISTLE, 0, 0));
        addBlock(activity, blocks, "CANTINA", Ui.BLUE, new RoutineStep(ActionType.CANTINA, 0, 0));
        builder.addView(blocks);

        StringBuilder draftText = new StringBuilder();
        for (int i = 0; i < activity.draft().size(); i++) {
            if (i > 0) draftText.append("  →  ");
            draftText.append(activity.draft().get(i).displayLabel());
        }
        TextView draft = Ui.text(activity,
                activity.draft().isEmpty() ? "Your routine is empty." : draftText.toString(),
                13, true, activity.draft().isEmpty() ? Ui.MUTED : Ui.NAVY);
        draft.setPadding(Ui.dp(activity, 10), Ui.dp(activity, 12), Ui.dp(activity, 10), Ui.dp(activity, 12));
        draft.setBackground(Ui.round(activity, "#EDF8FE", 14));
        builder.addView(draft, Ui.matchWrap(activity, 0, 10, 0, 8));
        builder.addView(buttons(activity,
                small(activity, "CLEAR", "#718391", activity::clearDraft),
                small(activity, "SAVE ROUTINE", Ui.GREEN, activity::saveDraft)));
        page.addView(builder, Ui.matchWrap(activity, 0, 10, 0, 0));

        LinearLayout saved = Ui.section(activity, "My Saved Routines",
                activity.routines().isEmpty() ? "No custom routines saved yet." : "Tap Play to run one.");
        for (Routine routine : new ArrayList<>(activity.routines())) {
            LinearLayout row = new LinearLayout(activity);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = Ui.text(activity, routine.name, 15, true, Ui.INK);
            row.addView(name, new LinearLayout.LayoutParams(0, Ui.dp(activity, 50), 1));
            Button play = small(activity, "PLAY", Ui.BLUE, () -> activity.playRoutine(routine));
            row.addView(play, new LinearLayout.LayoutParams(Ui.dp(activity, 100), Ui.dp(activity, 44)));
            Button delete = small(activity, "DELETE", Ui.RED, () -> activity.deleteRoutine(routine));
            LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(Ui.dp(activity, 100), Ui.dp(activity, 44));
            deleteParams.setMargins(Ui.dp(activity, 8), 0, 0, 0);
            row.addView(delete, deleteParams);
            saved.addView(row, Ui.matchWrap(activity, 0, 5, 0, 5));
        }
        page.addView(saved, Ui.matchWrap(activity, 0, 10, 0, 0));
        return Ui.scrollPage(activity, page);
    }

    private static void addBlock(MainActivity activity, GridLayout grid, String title, String color, RoutineStep step) {
        Button button = Ui.button(activity, title, color, Ui.WHITE, 12);
        button.setOnClickListener(v -> activity.addDraft(step));
        grid.addView(button, Ui.fixedGridCell(activity, 54));
    }

    static View games(MainActivity activity) {
        LinearLayout page = base(activity, "R2-D2 Games", "Pick a game, clear some floor space, and press Start.");
        LinearLayout statusCard = Ui.section(activity, activity.gameTitle, activity.gameDetail);
        statusCard.addView(small(activity, "STOP GAME", Ui.RED, activity.games()::stop),
                new LinearLayout.LayoutParams(-1, Ui.dp(activity, 48)));
        page.addView(statusCard);

        GridLayout grid = new GridLayout(activity);
        grid.setColumnCount(3);
        grid.addView(game(activity, "🔵", "RED LIGHT / BLUE LIGHT",
                "Blue means go. R2 turns away and plays music. Red means freeze!", Ui.BLUE,
                activity.games()::redLightGreenLight), Ui.gridCell(activity));
        grid.addView(game(activity, "♫", "FREEZE DANCE",
                "Dance until R2 suddenly stops and turns red.", Ui.PURPLE,
                activity.games()::freezeDance), Ui.gridCell(activity));
        grid.addView(game(activity, "★", "R2 SAYS",
                "Follow the silly command R2 gives you.", Ui.GREEN,
                activity.games()::r2Says), Ui.gridCell(activity));
        grid.addView(game(activity, "◀▶", "COPY R2",
                "Watch his head and light pattern, then copy it.", Ui.TEAL,
                activity.games()::copyR2), Ui.gridCell(activity));
        grid.addView(game(activity, "?", "SOUND GUESS",
                "Guess which R2-D2 sound you heard.", Ui.ORANGE,
                activity.games()::soundGuess), Ui.gridCell(activity));
        grid.addView(game(activity, "⌕", "TREASURE HUNT",
                "Find the object R2-D2 asks for.", "#D85A7F",
                activity.games()::treasureHunt), Ui.gridCell(activity));
        grid.addView(game(activity, "⚑", "PATROL MISSION",
                "R2 patrols, scans, and finishes his mission.", "#607D8B",
                activity.games()::patrol), Ui.gridCell(activity));
        page.addView(grid);
        return Ui.scrollPage(activity, page);
    }

    private static View game(MainActivity activity, String icon, String title, String body,
                             String color, Runnable play) {
        LinearLayout card = Ui.card(activity, Ui.WHITE);
        card.setPadding(Ui.dp(activity, 13), Ui.dp(activity, 12), Ui.dp(activity, 13), Ui.dp(activity, 13));
        TextView iconView = Ui.text(activity, icon, 27, true, color);
        iconView.setGravity(Gravity.CENTER);
        card.addView(iconView);
        TextView titleView = Ui.text(activity, title, 16, true, color);
        titleView.setGravity(Gravity.CENTER);
        card.addView(titleView, Ui.matchWrap(activity, 0, 4, 0, 0));
        TextView bodyView = Ui.text(activity, body, 12, false, Ui.MUTED);
        bodyView.setGravity(Gravity.CENTER);
        card.addView(bodyView, Ui.matchWrap(activity, 0, 6, 0, 10));
        Button start = Ui.button(activity, "START", color, Ui.WHITE, 13);
        start.setOnClickListener(v -> play.run());
        card.addView(start, new LinearLayout.LayoutParams(-1, Ui.dp(activity, 44)));
        return card;
    }

    static View interactive(MainActivity activity) {
        LinearLayout page = base(activity, "Interactive Modes",
                "These are all OFF by default. Turn on only the reactions you want R2-D2 to use.");
        page.addView(status(activity, activity.interactiveStatus, Ui.NAVY));
        page.addView(toggleCard(activity, "👏 CLAP MODE",
                "One clap makes R2 chirp and turn his head. Two claps start a dance.", "clap", false, Ui.PURPLE),
                Ui.matchWrap(activity, 0, 10, 0, 0));
        page.addView(toggleCard(activity, "♫ MUSIC MODE",
                "When R2 detects music, he dances and uses blue lights.", "music", false, Ui.BLUE),
                Ui.matchWrap(activity, 0, 10, 0, 0));
        page.addView(toggleCard(activity, "💬 TALK TO R2",
                "R2 waits for you to finish speaking, then answers with a sound and head gesture.", "talk", false, Ui.GREEN),
                Ui.matchWrap(activity, 0, 10, 0, 0));
        page.addView(toggleCard(activity, "⚠ GUARD MODE",
                "R2 reacts with a red alert when his infrared sensor detects something close.", "guard", false, Ui.RED),
                Ui.matchWrap(activity, 0, 10, 0, 0));

        LinearLayout note = Ui.section(activity, "Parent Tip",
                "These switches are also available in Parent Mode. Turning a mode off stops future automatic reactions.");
        page.addView(note, Ui.matchWrap(activity, 0, 10, 0, 0));
        return Ui.scrollPage(activity, page);
    }

    private static View toggleCard(MainActivity activity, String title, String body, String key,
                                   boolean defaultValue, String color) {
        LinearLayout card = Ui.card(activity, Ui.WHITE);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(Ui.dp(activity, 16), Ui.dp(activity, 13), Ui.dp(activity, 14), Ui.dp(activity, 13));
        LinearLayout labels = new LinearLayout(activity);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(Ui.text(activity, title, 18, true, color));
        labels.addView(Ui.text(activity, body, 13, false, Ui.MUTED), Ui.matchWrap(activity, 0, 5, 0, 0));
        card.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        Switch toggle = new Switch(activity);
        toggle.setChecked(activity.prefs().enabled(key, defaultValue));
        toggle.setOnCheckedChangeListener((button, enabled) -> activity.prefs().setEnabled(key, enabled));
        card.addView(toggle);
        return card;
    }

    static View voice(MainActivity activity) {
        LinearLayout page = base(activity, "Voice Commands", "Tap the microphone, then say a simple R2-D2 command.");
        LinearLayout card = Ui.section(activity, activity.voiceStatus,
                activity.voiceHeard.isEmpty()
                        ? "Try: R2 dance, go forward, turn left, red alert, go to sleep, or stop."
                        : "I heard: “" + activity.voiceHeard + "”");
        Button listen = Ui.bigButton(activity, "🎤  TAP TO TALK TO R2-D2", "#D85A7F");
        listen.setOnClickListener(v -> activity.requestVoice());
        card.addView(listen, new LinearLayout.LayoutParams(-1, Ui.dp(activity, 90)));
        card.addView(small(activity, "STOP LISTENING", Ui.RED, activity.voice()::stop),
                Ui.matchWrap(activity, 0, 10, 0, 0));
        page.addView(card);

        LinearLayout examples = Ui.section(activity, "Things You Can Say",
                "• Come alive\n• Go forward / back up\n• Turn left / right\n• Head left / center / right\n• Dance\n• Play a song\n• Red alert\n• Go to sleep\n• Stop");
        page.addView(examples, Ui.matchWrap(activity, 0, 10, 0, 0));
        return Ui.scrollPage(activity, page);
    }

    static View lights(MainActivity activity) {
        LinearLayout page = base(activity, "R2-D2 Lights", "Choose simple colors, flash patterns, or adjust red and blue brightness.");
        LinearLayout quick = Ui.section(activity, "Quick Light Buttons", "Easy one-tap light choices.");
        quick.addView(buttons(activity,
                small(activity, "BLUE", Ui.BLUE, () -> activity.motion().setLed(0, 255)),
                small(activity, "RED", Ui.RED, () -> activity.motion().setLed(255, 0)),
                small(activity, "PURPLE", Ui.PURPLE, () -> activity.motion().setLed(180, 180)),
                small(activity, "OFF", "#718391", () -> activity.motion().setLed(0, 0))));
        quick.addView(buttons(activity,
                small(activity, "POLICE FLASH", Ui.BLUE, () -> flash(activity, 8, 190)),
                small(activity, "PARTY FLASH", Ui.PURPLE, () -> flash(activity, 12, 130)),
                small(activity, "NIGHT LIGHT", Ui.TEAL, () -> activity.motion().setLed(0, 25))),
                Ui.matchWrap(activity, 0, 9, 0, 0));
        page.addView(quick);

        LinearLayout mixer = Ui.section(activity, "Make Your Own Color", "Move the red and blue sliders.");
        SeekBar red = new SeekBar(activity);
        red.setMax(255);
        SeekBar blue = new SeekBar(activity);
        blue.setMax(255);
        blue.setProgress(255);
        TextView values = Ui.text(activity, "Red 0     Blue 255", 15, true, Ui.INK);
        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int value, boolean user) {
                values.setText("Red " + red.getProgress() + "     Blue " + blue.getProgress());
                if (user) activity.motion().setLed(red.getProgress(), blue.getProgress());
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        };
        red.setOnSeekBarChangeListener(listener);
        blue.setOnSeekBarChangeListener(listener);
        mixer.addView(values);
        mixer.addView(red);
        mixer.addView(blue);
        page.addView(mixer, Ui.matchWrap(activity, 0, 10, 0, 0));
        return Ui.scrollPage(activity, page);
    }

    private static void flash(MainActivity activity, int count, long interval) {
        Handler handler = new Handler();
        for (int i = 0; i < count; i++) {
            final int index = i;
            final boolean red = index % 2 == 0;
            handler.postDelayed(() -> activity.motion().setLed(red ? 255 : 0, red ? 0 : 255), index * interval);
        }
        handler.postDelayed(() -> activity.motion().setLed(0, 0), count * interval);
    }

    static View parent(MainActivity activity) {
        LinearLayout page = base(activity, "Parent Mode", "Feature switches, safety tuning, advanced commands, sensors, and diagnostics.");

        LinearLayout features = Ui.section(activity, "What Cam Can See", "Turn child-facing sections on or off.");
        features.addView(toggleCard(activity, "Tilt Drive", "Show the tilt-driving card on the home screen.",
                "tilt", true, "#4E9D65"));
        features.addView(toggleCard(activity, "Voice Commands", "Show the voice-command card on the home screen.",
                "voice", true, "#D85A7F"), Ui.matchWrap(activity, 0, 8, 0, 0));
        features.addView(toggleCard(activity, "Games", "Show the game arcade on the home screen.",
                "games", true, Ui.GREEN), Ui.matchWrap(activity, 0, 8, 0, 0));
        features.addView(toggleCard(activity, "Game Controller", "Show Nintendo Switch / Android controller mode.",
                "controller", true, Ui.NAVY), Ui.matchWrap(activity, 0, 8, 0, 0));
        page.addView(features);

        LinearLayout automatic = Ui.section(activity, "Automatic Interactive Reactions",
                "All four default to OFF. They only react automatically while enabled.");
        automatic.addView(toggleCard(activity, "Clap Mode", "React to one or two claps.", "clap", false, Ui.PURPLE));
        automatic.addView(toggleCard(activity, "Music Mode", "Dance when music is detected.", "music", false, Ui.BLUE),
                Ui.matchWrap(activity, 0, 8, 0, 0));
        automatic.addView(toggleCard(activity, "Talk Mode", "Answer after a voice finishes.", "talk", false, Ui.GREEN),
                Ui.matchWrap(activity, 0, 8, 0, 0));
        automatic.addView(toggleCard(activity, "Guard Mode", "React to close infrared readings.", "guard", false, Ui.RED),
                Ui.matchWrap(activity, 0, 8, 0, 0));
        page.addView(automatic, Ui.matchWrap(activity, 0, 10, 0, 0));

        LinearLayout safety = Ui.section(activity, "Drive Safety and Fine Tuning", "Changes apply immediately.");
        safety.addView(setting(activity, "Tilt dead zone", 0, 50, activity.prefs().tiltDeadzone(), activity.prefs()::setTiltDeadzone));
        safety.addView(setting(activity, "Tilt sensitivity", 1, 100, activity.prefs().tiltSensitivity(), activity.prefs()::setTiltSensitivity));
        safety.addView(setting(activity, "Maximum continuous drive seconds", 2, 20,
                activity.prefs().maxDriveSeconds(), activity.prefs()::setMaxDriveSeconds));
        safety.addView(setting(activity, "180° spin timing in milliseconds", 600, 2200,
                activity.prefs().spin180Ms(), activity.prefs()::setSpin180Ms));
        page.addView(safety, Ui.matchWrap(activity, 0, 10, 0, 0));

        LinearLayout advanced = Ui.section(activity, "Advanced R2-D2 Controls",
                "The full recovered command library remains available here, away from the kid screens.");
        advanced.addView(small(activity, "OPEN ALL 1,431 COMMANDS", Ui.NAVY,
                () -> activity.showScreen(MainActivity.LIBRARY)), new LinearLayout.LayoutParams(-1, Ui.dp(activity, 54)));
        advanced.addView(buttons(activity,
                small(activity, "RAW PACKET", Ui.PURPLE, activity::rawPacketDialog),
                small(activity, "VOLUME LAB", Ui.ORANGE, activity::experimentalVolumeDialog),
                small(activity, "POWER DOWN", Ui.RED, activity.motion()::powerDown)), Ui.matchWrap(activity, 0, 9, 0, 0));
        advanced.addView(buttons(activity,
                small(activity, "RECONNECT", Ui.BLUE, activity::reconnect),
                small(activity, "RENAME", Ui.TEAL, activity::editControllerName),
                small(activity, "COPY DIAGNOSTICS", "#607D8B", activity::copyDiagnostics)),
                Ui.matchWrap(activity, 0, 9, 0, 0));
        advanced.addView(buttons(activity,
                small(activity, "EXPORT ROUTINES", Ui.GREEN, activity::exportRoutines),
                small(activity, "IMPORT ROUTINES", Ui.BLUE, activity::importRoutines)),
                Ui.matchWrap(activity, 0, 9, 0, 0));
        page.addView(advanced, Ui.matchWrap(activity, 0, 10, 0, 0));

        LinearLayout telemetry = Ui.section(activity, "Live R2-D2 Sensors",
                "Body position, head position, infrared, microphone, signal strength, and last packet.");
        TextView live = Ui.text(activity, activity.robot().summary(), 12, false, Ui.INK);
        live.setPadding(Ui.dp(activity, 10), Ui.dp(activity, 10), Ui.dp(activity, 10), Ui.dp(activity, 10));
        live.setBackground(Ui.round(activity, "#EDF8FE", 14));
        telemetry.addView(live);
        liveState(live, activity);
        telemetry.addView(buttons(activity,
                small(activity, "REQUEST INPUT", Ui.BLUE,
                        () -> activity.motion().sendPacket("Request input", Protocol.requestInput(), false)),
                small(activity, "REQUEST LVD", Ui.TEAL,
                        () -> activity.motion().sendPacket("Request LVD", Protocol.requestLvd(), false)),
                small(activity, "REQUEST VOLUME", Ui.PURPLE,
                        () -> activity.motion().sendPacket("Request volume", Protocol.requestVolume(), false))),
                Ui.matchWrap(activity, 0, 9, 0, 0));
        page.addView(telemetry, Ui.matchWrap(activity, 0, 10, 0, 0));

        LinearLayout log = Ui.section(activity, "Live BLE Event Log", "Connection, commands, responses, routines, and safety events.");
        TextView logText = Ui.text(activity, AppLog.text(), 10, false, Ui.INK);
        log.addView(logText);
        logText.postDelayed(new Runnable() {
            @Override public void run() {
                if (logText.isAttachedToWindow()) {
                    logText.setText(AppLog.text());
                    logText.postDelayed(this, 1000);
                }
            }
        }, 1000);
        page.addView(log, Ui.matchWrap(activity, 0, 10, 0, 0));
        return Ui.scrollPage(activity, page);
    }

    static View library(MainActivity activity) {
        LinearLayout page = base(activity, "Full Command Library", "Search every recovered sound, animation, motor sequence, LED sequence, position, and packet.");

        EditText search = new EditText(activity);
        search.setHint("Search: song, whistle, turn, startled, 17 02...");
        search.setTextColor(Color.BLACK);
        search.setHintTextColor(Ui.color("#7A8F9E"));
        search.setBackground(Ui.bordered(activity, Ui.WHITE, "#9CCBE6", 16));
        search.setPadding(Ui.dp(activity, 12), 0, Ui.dp(activity, 12), 0);

        Spinner category = new Spinner(activity);
        String[] categories = {"All", "HLSequence", "MotorSequence", "LEDSequence", "PNum",
                "mMotorSequences", "HeadPosition", "CamPosition", "LEDColor"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(activity,
                android.R.layout.simple_spinner_dropdown_item, categories);
        category.setAdapter(adapter);

        LinearLayout filters = new LinearLayout(activity);
        filters.addView(search, new LinearLayout.LayoutParams(0, Ui.dp(activity, 50), 1));
        LinearLayout.LayoutParams spinnerParams = new LinearLayout.LayoutParams(Ui.dp(activity, 190), Ui.dp(activity, 50));
        spinnerParams.setMargins(Ui.dp(activity, 8), 0, 0, 0);
        filters.addView(category, spinnerParams);
        page.addView(filters);

        LinearLayout results = new LinearLayout(activity);
        results.setOrientation(LinearLayout.VERTICAL);
        ScrollView resultScroll = new ScrollView(activity);
        resultScroll.addView(results);
        page.addView(resultScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        Runnable refresh = () -> {
            results.removeAllViews();
            List<CommandItem> list = activity.catalog().search(search.getText().toString(),
                    String.valueOf(category.getSelectedItem()), 120);
            results.addView(Ui.text(activity,
                    "Showing " + list.size() + " of " + activity.catalog().all().size() + " commands",
                    12, true, Ui.NAVY), Ui.matchWrap(activity, 0, 8, 0, 5));
            for (CommandItem item : list) {
                LinearLayout row = Ui.card(activity, Ui.WHITE);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(Ui.dp(activity, 12), Ui.dp(activity, 8), Ui.dp(activity, 8), Ui.dp(activity, 8));
                LinearLayout labels = new LinearLayout(activity);
                labels.setOrientation(LinearLayout.VERTICAL);
                labels.addView(Ui.text(activity, item.name.replace('_', ' '), 14, true, Ui.INK));
                labels.addView(Ui.text(activity,
                        item.category + " #" + item.id + "  •  " + Protocol.hex(item.packet),
                        11, false, Ui.MUTED));
                row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
                Button play = Ui.button(activity, "PLAY", Ui.BLUE, Ui.WHITE, 12);
                play.setOnClickListener(v -> activity.motion().sendPacket(item.name, item.packet, false));
                row.addView(play, new LinearLayout.LayoutParams(Ui.dp(activity, 90), Ui.dp(activity, 42)));
                results.addView(row, Ui.matchWrap(activity, 0, 4, 0, 4));
            }
        };

        search.setOnEditorActionListener((view, actionId, event) -> { refresh.run(); return true; });
        category.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { refresh.run(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refresh.run(); }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });
        refresh.run();
        return page;
    }

    private interface IntSetter { void set(int value); }

    private static View setting(MainActivity activity, String name, int min, int max, int current, IntSetter setter) {
        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView label = Ui.text(activity, name + ": " + current, 13, true, Ui.INK);
        SeekBar bar = new SeekBar(activity);
        bar.setMax(max - min);
        bar.setProgress(current - min);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int value, boolean user) {
                int adjusted = value + min;
                label.setText(name + ": " + adjusted);
                if (user) setter.set(adjusted);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        box.addView(label);
        box.addView(bar);
        return box;
    }

    private static void liveState(TextView text, MainActivity activity) {
        text.postDelayed(new Runnable() {
            @Override public void run() {
                if (text.isAttachedToWindow()) {
                    text.setText(activity.robot().summary());
                    text.postDelayed(this, 800);
                }
            }
        }, 800);
    }
}
